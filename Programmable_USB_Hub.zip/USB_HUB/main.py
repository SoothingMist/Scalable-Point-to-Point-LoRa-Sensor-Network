
# This program looks for two serial ports.
# Data from one is sent to the other.
# Thus, it is possible to send data from one device to another
# when those two devices cannot be plugged together.

# Required for working with serial ports
# https://pypi.org/project/pyserial
import serial.tools.list_ports

# Required to keep track of time.
import time

# Constants associated with the two serial ports.
PORT_A = None
#PORT_A_NAME = 'COM12' # Windows
PORT_A_NAME = '/dev/ttyACM1' # Linux
PORT_A_BAUD_RATE = 9600
PORT_B = None
#PORT_B_NAME = 'COM11' # Windows
PORT_B_NAME = '/dev/ttyACM0' # Linux
PORT_B_BAUD_RATE = 9600
MAX_MESSAGE_LENGTH = 15

# List all serial ports that have an PORT_A microcontroller plugged in.
# https://be189.github.io/lessons/10/control_of_PORT_A_with_python.html#
def FindSerialPorts():
  print("\nSerial ports:")
  Ports = serial.tools.list_ports.comports()
  found = False
  if Ports is not None:
    print("Detected ", len(Ports), " total ports")
    for port in Ports:
      #if port.manufacturer is not None and "PORT_A" in port.manufacturer:
        print(port.name, " : ", port.device, " : ", port.manufacturer)
        found = True
  if not found: print("No ports found")
  print()

# Main Process
if __name__ == '__main__':
  
  # Use this if uncertain as to which serial ports are active
  FindSerialPorts()
  #exit(0)

  print("Configuring serial ports...")

  # Connect to PORT_A
  try:
    PORT_A = serial.Serial(PORT_A_NAME, PORT_A_BAUD_RATE)
  except Exception as e:
    print(f'\nCaught {type(e)}:\n', e)  # https://docs.python.org/3/tutorial/errors.html
    print("\nIs the PORT_A device connected and active?")
    print("Has PORT_A's name and baudrate been correctly specified?")
    print("Is PORT_A's IDE Serial Monitor deactivated?")
    print("Exiting program.\n")
    exit(1)
  time.sleep(5)  # wait long enough for the device to be ready
  # Get the "I am ready" message.
  # https://realpython.com/python-print/#preventing-line-breaks
  # https://stackoverflow.com/questions/14292746/how-to-python-convert-bytes-to-readable-ascii-unicode
  while PORT_A.in_waiting > 0: print((PORT_A.read(1).decode("ascii")), end = '')
  print("Connected to PORT_A.")
  print('\tPort Name: ', PORT_A.name)
  print('\tPort Baudrate: ', PORT_A.baudrate, '\n')

  # Connect to PORT_B
  try:
    PORT_B = serial.Serial(PORT_B_NAME, PORT_B_BAUD_RATE)
  except Exception as e:
    print(f'\nCaught {type(e)}:\n', e)  # https://docs.python.org/3/tutorial/errors.html
    print("\nIs the PORT_B device connected and active?")
    print("Has PORT_B's name and baudrate been correctly specified?")
    print("Is PORT_B's IDE Serial Monitor deactivated?")
    print("Exiting program.\n")
    exit(1)
  time.sleep(5)  # wait long enough for the device to be ready
  # Get the "I am ready" message.
  # https://realpython.com/python-print/#preventing-line-breaks
  # https://stackoverflow.com/questions/14292746/how-to-python-convert-bytes-to-readable-ascii-unicode
  while PORT_B.in_waiting > 0: print((PORT_B.read(1).decode("ascii")), end = '')
  print("Connected to PORT_B.")
  print('\tPort Name: ', PORT_B.name)
  print('\tPort Baudrate: ', PORT_B.baudrate)

  #Bounce data between HUB Devices

  # Initialize Sequence.
  message = "012345678901234".encode("utf-8")
  PORT_A.write(message)
  PORT_A.flush()

  # Cycle Messages
  m = 0
  print()
  # while True: # for continuous operation
  while m <= 10: # for testing
    if PORT_A.in_waiting > 0:
      while PORT_A.in_waiting < MAX_MESSAGE_LENGTH: time.sleep(0.5)
      message = PORT_A.read(MAX_MESSAGE_LENGTH)
      PORT_B.write(message)
      PORT_B.flush()
      print("PORT_A read and sent: ", message)
      m += 1
    elif PORT_B.in_waiting > 0:
      while PORT_B.in_waiting < MAX_MESSAGE_LENGTH: time.sleep(0.5)
      message = PORT_B.read(MAX_MESSAGE_LENGTH)
      PORT_A.write(message)
      PORT_A.flush()
      print("PORT_B read and sent: ", message)
      m += 1
    else: continue

  # Finished
  print("\nFinished.\n")
  PORT_A.close()
  PORT_B.close()
  exit(0)
