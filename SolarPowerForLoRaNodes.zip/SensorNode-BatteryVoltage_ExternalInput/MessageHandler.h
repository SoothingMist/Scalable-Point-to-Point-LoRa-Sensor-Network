
#pragma once

// Enables Serial.println diagnostics. Use when running with Serial Monitor.
//#define DEBUG

// Unique ID of this node.
// Relay nodes always have ID = 0.
// They do not originate messages.
// They only rebroadcast messages.
#define THIS_NODE_ID 6
#define THIS_SYSTEM_ID 111

// Adds Arduino's capabilities.
// https://stackoverflow.com/questions/10612385/strings-in-c-class-file-for-arduino-not-compiling
#include <Arduino.h>

// Access to LoRa libraries.
// Install the RadioHead library using Tools/ManageLibraries.
// Compilation may yield, "#warning RH_LoRaFileOps unfinished".
// This does not matter. RadiHead is a work in process.
// We are not using RH_LoRaFileOps.
#include <SPI.h>
#include <RH_RF95.h>

// Byte locations of header components within a message.
// See MessageContents.html for a detailed explanation.
#define LOCATION_MESSAGE_BYTES   0
#define LOCATION_CRC             1
#define LOCATION_SYSTEM_ID       3
#define LOCATION_SOURCE_ID       4
#define LOCATION_DESTINATION_ID  5
#define LOCATION_MESSAGE_ID      6
#define LOCATION_MESSAGE_TYPE    8
#define LOCATION_SENSOR_ID       9
#define LOCATION_REBROADCASTS   10
#define MESSAGE_HEADER_LENGTH   11

// Maximum message contents length is set according to the RadioHead library.
#define MAX_MESSAGE_LENGTH RH_RF95_MAX_MESSAGE_LEN

// LED pin in case we want to use it to demonstrate activity, do not use pin 9
#define LED 13

class MessageHandler
{

public:

  // Constructor
  MessageHandler();

  // Send current sensor reading.
  bool SendReading(String notificationText, uint8_t destination);

private:

  // The message itself
  uint8_t Message[MAX_MESSAGE_LENGTH];
  const uint8_t NumFreeBytes = MAX_MESSAGE_LENGTH - MESSAGE_HEADER_LENGTH  - 1;
  uint8_t MessageIndex = 0; // byte possition in current message

  // Outgoing-message counter for this SYSTEM_ID/SOURCE_NODE_ID
  uint16_t sourceMessageID = 0;
  uint8_t sourceMessageID_HighByte = 0;
  uint8_t sourceMessageID_LowByte = 0;

  // Singleton instance of the radio driver
  RH_RF95 rf95;

  // Starts a message with its header
  bool StartMessage(uint8_t messageType, uint8_t destination);

  // Add the CRC check value to the message
  bool AddMessageCRC();

  // Transmit the message
  bool TransmitMessage();
  
  // CRC Calculation
  uint16_t checksumCalculator(uint8_t * data, uint16_t length);
};
