
#include "MessageConstruction.h" // class declaration
#include "crc-16-dnp.h" // for generating 16-bit CRC codes

// Constructor
MessageConstruction::MessageConstruction()
{
  // Basic initializations.
  // Will be set as needed.
  sourceMessageID = 0;
  sourceMessageID_HighByte = 0;
  sourceMessageID_LowByte = 0;
  MessageIndex = 0;

  // Initialize the cameras
  pixyVector = new Pixy2[MAX_CAMERAS];
  for(size_t c = 0; c < MAX_CAMERAS; c++)
  {
    pixyVector[c].init();
    pixyVector[c].changeProg("video");
  }
}

// Destructor
MessageConstruction::~MessageConstruction()
{
  delete [] pixyVector;
  pixyVector = NULL;
}

// Transmit a message
bool MessageConstruction::TransmitMessage()
{
  Serial.write(Message, MAX_MESSAGE_SIZE);
  Serial.flush();
  delay(2000); // wait a bit for message transmission to finish
}
  
// Starts a message with its header
bool MessageConstruction::StartMessage(uint8_t messageType, uint8_t destination)
{
  for(size_t i = 0; i < MAX_MESSAGE_SIZE; i++) Message[i] = 0;
  MessageIndex = 0;
  Message[MessageIndex++] = (uint8_t)'\r';
  Message[MessageIndex++] = SYSTEM_ID;
  Message[MessageIndex++] = SOURCE_NODE_ID;
  Message[MessageIndex++] = destination;
  sourceMessageID++;
  Message[MessageIndex++] = (uint8_t)(sourceMessageID >> 8); // high byte
  Message[MessageIndex++] = (uint8_t)((sourceMessageID << 8) >> 8); // low byte
  Message[MessageIndex++] = messageType;
  return true;
}

// Adds a 16-bit CRC check value to the message.
// Also adds message footer since CRC is at the end.
bool MessageConstruction::AddMessageCRC()
{
  uint16_t CRC_Check_Value = crcr16dnp(Message, MAX_MESSAGE_SIZE - ENVELOPE_FOOTER_SIZE, 0);
  //Serial.print("CRC: "); Serial.println(CRC_Check_Value);

//  // Show what is in the message -- For debugging.
//  Serial.println(); Serial.println(Message[255]);
//  Serial.println(CRC_Check_Value);
  
  Message[MAX_MESSAGE_SIZE - ENVELOPE_FOOTER_SIZE] = (uint8_t)(CRC_Check_Value >> 8); // high byte
  Message[MAX_MESSAGE_SIZE - ENVELOPE_FOOTER_SIZE + 1] = (uint8_t)((CRC_Check_Value << 8) >> 8); // low byte
  Message[MAX_MESSAGE_SIZE - ENVELOPE_FOOTER_SIZE + 2] = (uint8_t)'\n'; // be wary of "readln", message may also contain this character
}

// Send a start-image message
bool MessageConstruction::SendMessage_001(uint8_t sourceCameraID, uint8_t destination)
{
  // Check camera ID
  if(sourceCameraID > (MAX_CAMERAS - 1))
  {
    String errorMessage = "Camera ID " + String(sourceCameraID) + " not available on this node.";
    SendMessage_003(errorMessage, destination);
    return false;
  }
  else
  {
    // Start the message with a header
    StartMessage(001, destination);

    // Add the camera ID.
    Message[MessageIndex++] = sourceCameraID;

    // Add the image depth.
    Message[MessageIndex++] = IMAGE_DEPTH;
  
    // Add the frame dimensions.
    uint16_t factor = IMAGE_HEIGHT;
    Message[MessageIndex++] = (uint8_t)(factor >> 8); // high byte
    Message[MessageIndex++] = (uint8_t)((factor << 8) >> 8); // low byte
    factor = IMAGE_WIDTH;
    Message[MessageIndex++] = (uint8_t)(factor >> 8); // high byte
    Message[MessageIndex++] = (uint8_t)((factor << 8) >> 8); // low byte
    
    // Append message CRC and remaining footer
    AddMessageCRC();
  
    // Transmit the message
    TransmitMessage();

    return true;
  }
}

// Send a end-of-image message
bool MessageConstruction::SendMessage_002(uint8_t sourceCameraID, uint8_t destination)
{
  // Check camera ID
  if(sourceCameraID > (MAX_CAMERAS - 1))
  {
    String errorMessage = "Camera ID " + String(sourceCameraID) + " not available on this node.";
    SendMessage_003(errorMessage, destination);
    return false;
  }
  else
  {
    // Start with the message header
    StartMessage(002, destination);

    // Add the camera ID.
    Message[MessageIndex++] = sourceCameraID;

    // Append message CRC and remaining footer
    AddMessageCRC();
  
    // Transmit the message
    TransmitMessage();

    return true;
  }
}

// Send a general-notification message
bool MessageConstruction::SendMessage_003(String notificationText, uint8_t destination)
{
  // Start with the message header
  StartMessage(003, destination);
  
  // Add the notification text.
  if(notificationText.length() > MaxNotificationLength) notificationText = notificationText.substring(0, MaxNotificationLength - 1);
  Message[MessageIndex++] = notificationText.length();
  memcpy(Message + MessageIndex, notificationText.c_str(), notificationText.length());

  // Append message CRC and remaining footer
  AddMessageCRC();

  // Transmit the message
  TransmitMessage();

  return true;
}

// Send all segments of the image's pixels
bool MessageConstruction::SendMessage_000(uint8_t sourceCameraID, uint8_t destination)
{
  // Check validity of camera ID
  if(sourceCameraID > (MAX_CAMERAS - 1))
  {
    String errorMessage = "Camera ID " + String(sourceCameraID) + " not available on this node.";
    SendMessage_003(errorMessage, destination);
    return false;
  }
  else
  {
    // Take snapshot.
    // From my examination so far, Pixy2.1 cannot take static images.
    // Therefore, physically, the camera has to be held in a staring, continuous-dwell, position.
    // Motion in the image or the camera's motion changes the image as this code tries to send the image.
    // So know that the camera is in video mode. It does not deliver a static snapshot.

    // Paints the image row by row.
    // The number of columns is divided by SegmentSize,
    // the number of pixels that fit within a message envelope.
    // The standard envelope contains ENVELOPE_SIZE bytes.
    // The envelope for message type 000 contains an extra 5 bytes.
    const uint8_t SegmentSize = (uint8_t)((MAX_MESSAGE_SIZE - ENVELOPE_HEADER_SIZE - ENVELOPE_FOOTER_SIZE - 5) / IMAGE_DEPTH);

    // For segmenting the image.
    const uint8_t NumFullColumnBlocks =
      (uint8_t)((IMAGE_WIDTH - (2 * NUMBER_TO_SKIP)) / SegmentSize); // number of pixels in full column segments
    const uint8_t NumRemainingPixels =
      (uint8_t)((IMAGE_WIDTH - (2 * NUMBER_TO_SKIP)) % SegmentSize); // number of pixels in the remaining column subsegment

    // Serial.println(SegmentSize);
    // Serial.println(NumFullColumnBlocks);
    // Serial.println(NumRemainingPixels);
    // exit(0);

    // Number of rows and columns can be greater than 255 so we have to get low and high bytes of each.
    uint8_t row_HighByte;
    uint8_t row_LowByte;
    uint8_t column_HighByte;
    uint8_t column_LowByte;

    // Values of image colors.
    uint8_t red, green, blue;
  
    // Send messages containing pixels on a row-by-row basis.
    // Segments of each row's columns are selected as pixels to add to the message.
    // Each message contains no more than SegmentSize number of pixels.
    size_t pixelIndex = 0; // indexes the vector holding the pixel values received from the camera
    for (uint16_t r = NUMBER_TO_SKIP; r < IMAGE_HEIGHT - NUMBER_TO_SKIP; r++)
    {
      row_HighByte = (uint8_t)(r >> 8);
      row_LowByte = (uint8_t)((r << 8) >> 8);
      uint16_t c = NUMBER_TO_SKIP;

      // Go through each SegmentSize block of pixels
      for (uint8_t cb = 0; cb < NumFullColumnBlocks; cb++)
      {
        // Start with the message header
        StartMessage(000, destination);
        Message[MessageIndex++] = sourceCameraID;
        
        // Each message contains a block of column pixels for a given row.
        // row and column indicate where a given segment of pixels starts.
        Message[MessageIndex++] = row_HighByte;
        Message[MessageIndex++] = row_LowByte;
        column_HighByte = (uint8_t)(c >> 8);
        column_LowByte = (uint8_t)((c << 8) >> 8);
        Message[MessageIndex++] = column_HighByte;
        Message[MessageIndex++] = column_LowByte;
        Message[MessageIndex++] = SegmentSize;

        // Append the pixels in this segment.
        for (uint8_t ss = 0; ss < SegmentSize; ss++)
        {
          // Get this pixel's values
          pixyVector[sourceCameraID].video.getRGB(c, r, &red, &green, &blue, SATURATE);
          Message[MessageIndex++] = red;
          Message[MessageIndex++] = green;
          Message[MessageIndex++] = blue;
          
          // Increment the column counter
          c++;
        }

        // Append message CRC and remaining footer
        AddMessageCRC();
      
        // Transmit the message
        TransmitMessage();
      }
  
      // Send the pixels in the last partial segment of columns
      if(NumRemainingPixels > 0)
      {
        // Start with the message header
        StartMessage(000, destination);
        Message[MessageIndex++] = sourceCameraID;
        
        // Each message contains a block of column pixels for a given row.
        // row and column indicate where a given segment of pixels starts.
        Message[MessageIndex++] = row_HighByte;
        Message[MessageIndex++] = row_LowByte;
        column_HighByte = (uint8_t)(c >> 8);
        column_LowByte = (uint8_t)((c << 8) >> 8);
        Message[MessageIndex++] = column_HighByte;
        Message[MessageIndex++] = column_LowByte;
        Message[MessageIndex++] = NumRemainingPixels;
        
        for (c = c; c < IMAGE_WIDTH - NUMBER_TO_SKIP; c++)
        {
          // Get this pixel's values
          pixyVector[sourceCameraID].video.getRGB(c, r, &red, &green, &blue, SATURATE);
          Message[MessageIndex++] = red;
          Message[MessageIndex++] = green;
          Message[MessageIndex++] = blue;
        }
        
        // Append message CRC and remaining footer
        AddMessageCRC();
      
        // Transmit the message
        TransmitMessage();
      }
    }
  }
}
