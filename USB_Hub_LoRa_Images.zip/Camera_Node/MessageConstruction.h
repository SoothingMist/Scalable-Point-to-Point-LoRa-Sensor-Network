
#pragma once

// Enables Serial.println diagnostics. Use when running with Serial Monitor.
//#define DEBUG

// Per https://docs.pixycam.com/wiki/doku.php?id=wiki:v2:video_api
// The optional saturate argument when set to true (default) will scale all RGB values 
// such that the greatest of the three values (r, g and b) is maximized (saturated) 
// at 255. When set to false, the unmodified RGB values are returned.
#define SATURATE false

// Adds Arduino's capabilities.
// https://stackoverflow.com/questions/10612385/strings-in-c-class-file-for-arduino-not-compiling
#include <Arduino.h>

// Adds ability to read the Pixy2.1 camera.
// NOTE, THIS PROGRAM REQUIRES FIRMWARE VERSION 3.0.11 OR GREATER
// Important: The Pixy2 library is shipped with PIXY_DEBUG defined.
// This causes debug messages to be generated. These messages do not match this software's message format.
// This causes all subsequent messages to be rejected. To alleviate this situation, go to TPixy2.h in the 
// Arduino libraries Pixy2 folder. Open this file and comment out Line 23. Then rebuild this software.
#include <Pixy2.h>

// These constants are set for a given node within a given system.
// There is some indication that they can be made permanently 
// resident on the microcontroller board and queried. 
// That can be done once we learn how.
#define SYSTEM_ID 111
#define SOURCE_NODE_ID 001

// Messages are composed of envelope header, envelop footer, and content between those.
// LoRa message content has a maximum length.
// https://www.sciencedirect.com/topics/computer-science/maximum-packet-size#:~:text=LoRa%20offers%20a%20maximum%20packet,be%20found%20in%20%5B5%5D
#define MAX_MESSAGE_SIZE 251
#define ENVELOPE_HEADER_SIZE 8
#define ENVELOPE_FOOTER_SIZE 3

// Images have depth.
// Ex: An RGB image has depth of three. Grayscale has a depth of one.
// Software assumes a depth of no more than 255 and no less than 1.
// Presently using Pixy2.1 camera, an RGB camera, depth of 3.
#define IMAGE_DEPTH 3

// The number of cameras attached to the node running this software.
// Software assumes one. It is possible for there to be more so we are laying the groundwork for that.
#define MAX_CAMERAS 1

// Camera parameters.
// Obtained by running the included Pixy_video_get_rgb_camera_parameters program.
#define IMAGE_HEIGHT 208
#define IMAGE_WIDTH 316

// Number of rows and columns to skip at the image's edges.
// For Pixy2.1, each pixel referenced exists within a 5x5 box.
// The referenced pixel is the box' center pixel.
// The delivered pixel value is an average of those five pixels.
// Unable to find a reliable way of changing that.
#define NUMBER_TO_SKIP 2

class MessageConstruction
{

public:

  // Constructor
  MessageConstruction();

  // Destructor
  ~MessageConstruction();

  // Send specific messages to specific destinations.
  // 000 = pixel-level data, 001 = start new image, 002 = end of image. 003 = general notification.
  bool SendMessage_000(uint8_t sourceCameraID, uint8_t destination);
  bool SendMessage_001(uint8_t sourceCameraID, uint8_t destination);
  bool SendMessage_002(uint8_t sourceCameraID, uint8_t destination);
  bool SendMessage_003(String notificationText, uint8_t destination); // only ascii notifications are allowed

private:

  // The message itself
  uint8_t Message[MAX_MESSAGE_SIZE];
  const uint8_t MaxNotificationLength = MAX_MESSAGE_SIZE - ENVELOPE_HEADER_SIZE- ENVELOPE_FOOTER_SIZE - 1;
  uint8_t MessageIndex; // byte possition in current message

  // Outgoing-message counter for this SYSTEM_ID/SOURCE_NODE_ID
  uint16_t sourceMessageID;
  uint8_t sourceMessageID_HighByte;
  uint8_t sourceMessageID_LowByte;

  // Starts a message with its header
  bool StartMessage(uint8_t messageType, uint8_t destination);

  // Add the CRC check value to the message
  bool AddMessageCRC();

  // Transmit the message
  bool TransmitMessage();

  // Creates a vector of Pixy (camera) objects.
  // Do not know how to add more than one camera to Arduino.
  // This vector approach allows for that possibility.
  // We assume there will be at least one camera.
  Pixy2 *pixyVector;
};
