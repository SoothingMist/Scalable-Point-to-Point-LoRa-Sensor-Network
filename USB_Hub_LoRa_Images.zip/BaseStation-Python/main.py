
# https://www.geeksforgeeks.org/how-to-display-multiple-images-in-one-window-using-opencv-python
# https://answers.opencv.org/question/175912/how-to-display-multiple-images-in-one-window
# https://www.hackster.io/polyhedra64/how-to-link-arduino-serial-to-python-62b9a5

# Maybe interesting:
# https://stackoverflow.com/questions/50881227/display-images-in-a-grid

import cv2 # https://pypi.org/project/opencv-python
import numpy as np # https://numpy.org
import serial, serial.tools.list_ports # https://pypi.org/project/pyserial
import time # https://docs.python.org/3/library/time.html
import crcmod  # https://tanzolab.tanzilli.com/crc, https://pypi.org/project/crcmod

# Constants. These values should not be changed.

# Refers to serial port
Serial_Port = None
SERIAL_PORT_NAME = 'COM4' # Windows
#Serial_PORT_NAME = '/dev/ttyACM1' # Linux
SERIAL_PORT_BAUD_RATE = 9600

THIS_SYSTEM_ID = 111 # system within which this node is installed
THIS_NODE_ID = 0 # unique for each node containing this code
INITIAL_CRC_VALUE = 0 # CRC always initialized at this value
MAX_MESSAGE_SIZE = 251 # LoRa message content has a maximum size
EXPECTED_FINAL_MESSAGE = b"<done>"

# Location of elements in message string
SYSTEM_ID_LOCATION = 1
SOURCE_NODE_ID_LOCATION = 2
DESTINATION_NODE_ID_LOCATION = 3
SOURCE_MESSAGE_ID_LOCATION = 4 # occupies two bytes
MESSAGE_TYPE_LOCATION = 6

# Going global with these variables for now
image = None
cameraID = None

# List all serial ports that have a device plugged in.
# https://stackoverflow.com/questions/12090503/listing-available-com-ports-with-python
def FindSerialPorts():
  print("\nSerial Ports:")
  Ports = serial.tools.list_ports.comports()
  found = False
  if Ports is not None:
    print("Detected ", len(Ports), " total ports")
    for port in Ports:
      print(port.name, "\t:\t", port.device, "\t:\t", port.manufacturer)
      found = True
  if not found: print("No ports found")
  print()

# Connect to the correct serial port.
def ConnectSerialPort(GENERIC_PORT_NAME):
  global Serial_Port
  # Identify the device connected to one of the two ports
  try:
    Serial_Port = serial.Serial(SERIAL_PORT_NAME, SERIAL_PORT_BAUD_RATE)
  except Exception as thisException:  # https://docs.python.org/3/tutorial/errors.html
    print(f'\nCaught {type(thisException)}:\n', thisException)
    print("\nIs the ", GENERIC_PORT_NAME, " device connected and active?")
    print("Has ", GENERIC_PORT_NAME, " name and baudrate been correctly specified?")
    print("Is the IDE Serial Monitor of the device connected to ", GENERIC_PORT_NAME, " been deactivated?")
    Serial_Port = None
    return
  time.sleep(5)  # wait long enough for the device to be ready
  # Get the "ready" message, which contains the device's identifier.
  # https://realpython.com/python-print/#preventing-line-breaks
  # https://stackoverflow.com/questions/14292746/how-to-python-convert-bytes-to-readable-ascii-unicode
  identifier = ""
  while Serial_Port.in_waiting > 0: identifier += Serial_Port.read(1).decode("ascii")
  if identifier.find("Basestation Receiver") >= 0:
    print("Basestation connected to port ", Serial_Port.name)
  else:
    print("Received unknown device identifier: ", identifier)
    print('\tPort Name: ', Serial_Port.name)
    print("Exiting program.\n")
    Serial_Port.close()
    Serial_Port = None

# Unpack a received message
def UnpackMessage(thisMessage):
  if len(thisMessage) == MAX_MESSAGE_SIZE: # All messages have the same length

    # Check against CRC embedded in the message
    CRC_highByte = thisMessage[len(thisMessage) - 3]
    CRC_lowByte = thisMessage[len(thisMessage) - 2]
    expectedCRC = (CRC_highByte << 8) | CRC_lowByte

    # Select CRC-16-DNP to calculate received-message's CRC check value
    crc16 = crcmod.mkCrcFun(0x13D65, 0xFFFF, True, 0xFFFF)

    # Calculate received-message's CRC check value
    calculatedCRC = crc16(thisMessage[0 : len(thisMessage) - 3], INITIAL_CRC_VALUE)
    #for i in range(len(thisMessage)): print(int(thisMessage[i])) # for testing
    if expectedCRC == calculatedCRC:
      # Return the message ID
      highByte = thisMessage[SOURCE_MESSAGE_ID_LOCATION]
      lowByte = thisMessage[SOURCE_MESSAGE_ID_LOCATION + 1]
      msgID = (highByte << 8) | lowByte
      return msgID
    else: return None
  else: return None

# Main Process
if __name__ == '__main__':

  # Use this if uncertain as to which serial ports are active
  FindSerialPorts()
  # exit(0)

  # Identify the device connected to the serial port
  print("Configuring serial port...")
  ConnectSerialPort(SERIAL_PORT_NAME)
  if Serial_Port is None:
    print("\nDevice is not connected.")
    print("Exiting program.\n")
    exit(1)

  # Keep receiving and acting on messages until <done> message is received
  print("\nAwaiting Messages...\n")
  previousMessageID = 0
  notDone = True
  while notDone:

    # Receive next message
    message = Serial_Port.read(MAX_MESSAGE_SIZE)

    # Unpack the message
    messageID = UnpackMessage(message)

    if messageID is not None:
      print("Message ", messageID, " of type ", message[MESSAGE_TYPE_LOCATION], end = " ")
      if messageID != (previousMessageID + 1): print("Out of Sequence")
      else: print()
      previousMessageID = messageID
      # Check if message is for this node.
      # Act on message if for this node.
      if message[SYSTEM_ID_LOCATION] == THIS_SYSTEM_ID and\
         message[DESTINATION_NODE_ID_LOCATION] == THIS_NODE_ID:

        # Check for message type 3, a notification message
        if message[MESSAGE_TYPE_LOCATION] == 3:
          messageContents =\
            message[MESSAGE_TYPE_LOCATION + 2 :
                    MESSAGE_TYPE_LOCATION + 2 + message[MESSAGE_TYPE_LOCATION + 1]]
          print('\t', messageContents)
          if messageContents == EXPECTED_FINAL_MESSAGE: notDone = False

        # Check for message type 1, a start-new-image message
        elif message[MESSAGE_TYPE_LOCATION] == 1:
          # need to start a new image associated with a specific camera
          # https://stackoverflow.com/questions/47242918/how-to-create-an-image-from-a-matrix-using-opencv-python
          # https://numpy.org/doc/stable/reference/random/generated/numpy.random.randint.html
          cameraID = message[MESSAGE_TYPE_LOCATION + 1]
          imageDepth = message[MESSAGE_TYPE_LOCATION + 2]
          numRows =\
            (message[MESSAGE_TYPE_LOCATION + 3] << 8) | message[MESSAGE_TYPE_LOCATION + 4]
          numColumns =\
            (message[MESSAGE_TYPE_LOCATION + 5] << 8) | message[MESSAGE_TYPE_LOCATION + 6]

          # Creates image matrix with random pixel colors
          image =\
            np.random.randint(0, 255, size = (numRows, numColumns, imageDepth), dtype = np.uint8)

          # Populates image matrix with red color.
          # Note: OpenCV represents colors as Blue,Green,Red.
          for r in range(numRows):
            for c in range(numColumns):
              image[r, c, 0] = 0
              image[r, c, 1] = 0
              image[r, c, 2] = 255
          # display = np.array(image, dtype = np.uint8)
          # cv2.imshow('Test Image', display)
          # cv2.waitKey(0)
          # cv2.destroyWindow('Test Image')

        # Check for message type 2, an end-of-image message
        elif message[MESSAGE_TYPE_LOCATION] == 2:
          if cameraID == message[MESSAGE_TYPE_LOCATION + 1] and image is not None:
            print("\tImage will now display itself.")
            print("\tThe image\'s window may be hidden under some other application\'s window.")
            print("\tTo proceed further, click on the image window and click any key.")
            display = np.array(image, dtype = np.uint8)
            cv2.imshow('Test Image', display)
            cv2.waitKey(0)
            cv2.destroyWindow('Test Image')

        # Check for message type 0, insert pixel data into image
        elif message[MESSAGE_TYPE_LOCATION] == 0:
          if cameraID == message[MESSAGE_TYPE_LOCATION + 1] and image is not None:
            startRow =\
              (message[MESSAGE_TYPE_LOCATION + 2] << 8) | message[MESSAGE_TYPE_LOCATION + 3]
            startColumn =\
              (message[MESSAGE_TYPE_LOCATION + 4] << 8) | message[MESSAGE_TYPE_LOCATION + 5]
            numPixels = message[MESSAGE_TYPE_LOCATION + 6]
            messageByteIndex = MESSAGE_TYPE_LOCATION + 6
            for p in range(numPixels):
              # Get the pixel for the current column and put it in the image
              messageByteIndex += 1
              image[startRow, startColumn, 2] = message[messageByteIndex]
              messageByteIndex += 1
              image[startRow, startColumn, 1] = message[messageByteIndex]
              messageByteIndex += 1
              image[startRow, startColumn, 0] = message[messageByteIndex]
              # Get the next column
              startColumn += 1

    else:
      print("Unidentifiable Message Rejected")

  # Finished
  print("\nFinished.\n")
  Serial_Port.close()
  Serial_Port = None
  exit(0)
