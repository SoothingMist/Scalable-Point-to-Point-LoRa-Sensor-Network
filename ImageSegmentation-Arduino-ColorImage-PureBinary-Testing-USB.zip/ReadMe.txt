
The software herein uses an Arduino Uno microcontroller board to send a Pixy2 camera immage to a PC via a USB serial connection.

ImageReconstruction is a Python program that runs on a PC. It opens the serial port created by the microcontroller.

ImageSegmentation-Arduino-ColorImage-PureBinary-Testing-USB is a C++ program thar runs on the microcontroller.

A 256-byte message size is selected because that is the largest that can be used during LoRa communication. LoRa is not used by this software. That is coming later.

It takes about 20 minutes for the image to be fully transmitted. In the end, the camera image is displayed.

The assumed camera is Pixy2.1. To purchase, see https://amzn.to/3zXtiGO. Connection instructions can be found at https://docs.pixycam.com/wiki/doku.php?id=wiki:v2:pixy_regular_quick_start.

More documentation is coming. For now, it is assumed the reader is familiar with Arduino Uno and Python.