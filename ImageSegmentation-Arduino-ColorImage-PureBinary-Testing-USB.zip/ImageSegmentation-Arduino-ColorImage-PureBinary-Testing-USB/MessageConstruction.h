
#pragma once

// Adds Arduino's capabilities
// https://stackoverflow.com/questions/10612385/strings-in-c-class-file-for-arduino-not-compiling
#include <Arduino.h>

// Adds ability to read the Pixy2.1 camera.
// NOTE, THIS PROGRAM REQUIRES FIRMWARE VERSION 3.0.11 OR GREATER
// IMPORTANT: The Pixy2 library is shipped with PIXY_DEBUG defined.
// This causes debug messages to be generated. These messages do not match this software's message format.
// This causes all subsequent messages to be rejected. To alleviate this situation, go to TPixy2.h in the 
// Arduino libraries Pixy2 folder. Open this file and comment out Line 23. Then rebuild this software.
// IMPORTANT: The Pixy2 camera does not read just one pixel value. Rather, it averages the pixel values
// surrounding the specified pixel. According to https://docs.pixycam.com/wiki/doku.php?id=wiki:v2:video_api,
// "getRGB() takes a 5×5 section of pixels centered at the x, y location and performs an average of all
// 25 pixels to obtain a representative result". According to
// https://docs.pixycam.com/wiki/doku.php?id=wiki:v2:protocol_reference#getrgb-x-y-r-g-b-saturate,
// exactly 5x5 pixels seem to be involved. Although the documentation says that fewer pixels are averaged at the edges
// of the image, my experience has been spurious results in the last two rows. So, no single-pixel values are or can be 
// read, given the current version. For this reason, this present software begins with the third row and ends with the 
// last row minus 2. Same with columns. One could try modifying the code in the library but there is no telling what the
// hardware/firmware would do in that case.
// IMPORTANT: getRGB() defaults to "saturate", be sure to set this option to false manually if you want the actual average
// of pixel values.
#include <Pixy2.h>

// These constants are set for a given node within a given system.
// There is some indication that they can be made permanently 
// resident on the microcontroller board and queried. 
// That can be done once we learn how.
#define SYSTEM_ID 111
#define SOURCE_NODE_ID 001

// Messages are composed of envelope header, envelop footer, and content inbetween those.
// LoRa messages can be no longer than 256 bytes.
// https://www.sciencedirect.com/topics/computer-science/maximum-packet-size#:~:text=LoRa%20offers%20a%20maximum%20packet,be%20found%20in%20%5B5%5D.
#define MAX_MESSAGE_SIZE 256
#define ENVELOPE_HEADER_SIZE 8
#define ENVELOPE_FOOTER_SIZE 3

// Images have depth.
// Ex: An RGB image has depth of three.
// Software assumes a depth of no more than 255 and no less than 1.
// Software assumes use of Pixy2.1 camera, an RGB camera.
#define IMAGE_DEPTH 3

// The number of cameras attached to the node running this software.
#define MAX_CAMERAS 1

// Number of rows and columns to skip at the image's edges.
// See comments at top of this file for explanation.
#define NUMBER_TO_SKIP 2

class MessageConstruction
{

public:

  // Constructor
  MessageConstruction();

  // Destructor
  ~MessageConstruction();

  // Send specific messages to specific destinations.
  // 000 = pixel-level data, 001 = start new image, 002 = end of image. 003 = general notification.
  bool SendMessage_000(uint8_t sourceCameraID, uint8_t destination);
  bool SendMessage_001(uint8_t sourceCameraID, uint8_t destination);
  bool SendMessage_002(uint8_t sourceCameraID, uint8_t destination);
  bool SendMessage_003(String notificationText, uint8_t destination); // only ascii notifications are allowed

private:

  // The message itself
  uint8_t Message[MAX_MESSAGE_SIZE];
  const uint8_t MaxNotificationLength = MAX_MESSAGE_SIZE - ENVELOPE_HEADER_SIZE- ENVELOPE_FOOTER_SIZE - 1;
  uint8_t MessageIndex; // points to the current message index

  // Outgoing-message counter for this SYSTEM_ID/SOURCE_NODE_ID
  uint16_t sourceMessageID;
  uint8_t sourceMessageID_HighByte;
  uint8_t sourceMessageID_LowByte;

  // Starts a message with its header
  bool StartMessage(uint8_t messageType, uint8_t destination);

  // Add the CRC check value to the message
  bool AddMessageCRC();

  // Transmit the message
  bool TransmitMessage();


  // Creates a vector of Pixy (camera) objects.
  // Do not know how to add more than one camera to Arduino.
  // This vector approach allows for that possibility.
  // We assume there will be at least one camera.
  Pixy2 *pixyVector;
};
