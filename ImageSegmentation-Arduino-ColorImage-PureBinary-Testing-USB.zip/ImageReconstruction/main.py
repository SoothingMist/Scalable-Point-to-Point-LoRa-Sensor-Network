
# https://www.geeksforgeeks.org/how-to-display-multiple-images-in-one-window-using-opencv-python
# https://answers.opencv.org/question/175912/how-to-display-multiple-images-in-one-window
# https://www.hackster.io/polyhedra64/how-to-link-arduino-serial-to-python-62b9a5

# Maybe interesting:
# https://stackoverflow.com/questions/50881227/display-images-in-a-grid

import cv2
import numpy as np
import serial
import time
import crcmod  # https://tanzolab.tanzilli.com/crc

# Constants. These values should not be changed.
THIS_SYSTEM_ID = 111 # system within which this node is installed
THIS_NODE_ID = 0 # unique for each node containing this code
INITIAL_CRC_VALUE = 0
MAX_MESSAGE_SIZE = 256 # LoRa messages can be no longer than 256 bytes
EXPECTED_INITIAL_NOTIFICATION = b"<Arduino is Ready>"
EXPECTED_FINAL_MESSAGE = b"<done>"
# Location of elements in message string
SYSTEM_ID_LOCATION = 1
SOURCE_NODE_ID_LOCATION = 2
DESTINATION_NODE_ID_LOCATION = 3
SOURCE_MESSAGE_ID_LOCATION = 4 # occupies two bytes
MESSAGE_TYPE_LOCATION = 6

# Going global for now with these
image = None
cameraID = None
message_counter = 0

# Unpack a received message
def UnpackMessage(thisMessage):
  global message_counter
  if len(thisMessage) == MAX_MESSAGE_SIZE: # All messages have the same length
    message_counter += 1

    # Check against CRC embedded in the message
    CRC_highByte = thisMessage[len(thisMessage) - 3]
    CRC_lowByte = thisMessage[len(thisMessage) - 2]
    expectedCRC = (CRC_highByte << 8) | CRC_lowByte

    # Select CRC-16-DNP to calculate received-message's CRC check value
    crc16 = crcmod.mkCrcFun(0x13D65, 0xFFFF, True, 0xFFFF)

    # Calculate received-message's CRC check value
    calculatedCRC = crc16(thisMessage[0 : len(thisMessage) - 3], INITIAL_CRC_VALUE)
    #for i in range(len(thisMessage)): print(int(thisMessage[i])) # for testing
    if expectedCRC == calculatedCRC:
      # Return the message ID
      highByte = thisMessage[SOURCE_MESSAGE_ID_LOCATION]
      lowByte = thisMessage[SOURCE_MESSAGE_ID_LOCATION + 1]
      msgID = (highByte << 8) | lowByte
      return msgID
    else:
      return None
  else: return None

# Open port to Arduino Uno microcontroller
targetSerialPortName = 'COM4'
targetSerialPortBaudRate = 9600
Arduino = None
try:
  Arduino = serial.Serial(targetSerialPortName, targetSerialPortBaudRate)
except Exception as e:
  print(f'\nCaught {type(e)}:\n', e) # https://docs.python.org/3/tutorial/errors.html
  print("\nIs the Arduino Uno microcontroller connected and active?")
  print("Is the Arduino IDE's Serial Monitor deactivated?")
  print("Exiting program.\n")
  exit(1)
print("Connected to Arduino Uno microcontroller.")
time.sleep(5) # waiting long enough for the microcontroller side to be ready

# Make sure the serial buffer is empty before starting the microcontroller.
while Arduino.in_waiting > 0: message = Arduino.read(1)

# Once serial buffer is empty, send start message to the microcontroller.
Arduino.write(b'go\r\n')

# Keep receiving and acting on messages until <done> message is received
notDone = True
while notDone:

  # Receive next message
  while Arduino.in_waiting <= 0: time.sleep(1)
  message = Arduino.read(MAX_MESSAGE_SIZE)

  # Unpack the message
  messageID = UnpackMessage(message)

  if messageID is not None:
    print("Message ", message_counter)
    # Check if message is for this node.
    # Act on message if for this node.
    if message[SYSTEM_ID_LOCATION] == THIS_SYSTEM_ID and\
       message[DESTINATION_NODE_ID_LOCATION] == THIS_NODE_ID:

      # Check for message type 3, a notification message
      if message[MESSAGE_TYPE_LOCATION] == 3:
        messageContents =\
          message[MESSAGE_TYPE_LOCATION + 2 :
                  MESSAGE_TYPE_LOCATION + 2 + message[MESSAGE_TYPE_LOCATION + 1]]
        print(messageContents)
        if messageContents == EXPECTED_FINAL_MESSAGE: notDone = False

      # Check for message type 1, a start-new-image message
      elif message[MESSAGE_TYPE_LOCATION] == 1:
        # need to start a new image associated with a specific camera
        # https://stackoverflow.com/questions/47242918/how-to-create-an-image-from-a-matrix-using-opencv-python
        # https://numpy.org/doc/stable/reference/random/generated/numpy.random.randint.html
        cameraID = message[MESSAGE_TYPE_LOCATION + 1]
        imageDepth = message[MESSAGE_TYPE_LOCATION + 2]
        numRows =\
          (message[MESSAGE_TYPE_LOCATION + 3] << 8) | message[MESSAGE_TYPE_LOCATION + 4]
        numColumns =\
          (message[MESSAGE_TYPE_LOCATION + 5] << 8) | message[MESSAGE_TYPE_LOCATION + 6]

        # Creates image matrix with random pixel colors
        image =\
          np.random.randint(0, 255,
                            size = (numRows, numColumns, imageDepth), dtype = np.uint8)

        # Populates image matrix with red color.
        # Note: OpenCV represents colors as Blue,Green,Red.
        for r in range(numRows):
          for c in range(numColumns):
            image[r, c, 0] = 0
            image[r, c, 1] = 0
            image[r, c, 2] = 255
        # display = np.array(image, dtype = np.uint8)
        # cv2.imshow('Test Image', display)
        # cv2.waitKey(0)
        # cv2.destroyWindow('Test Image')

      # Check for message type 2, an end-of-image message
      elif message[MESSAGE_TYPE_LOCATION] == 2:
        if cameraID == message[MESSAGE_TYPE_LOCATION + 1] and image is not None:
          display = np.array(image, dtype = np.uint8)
          cv2.imshow('Test Image', display)
          cv2.waitKey(0)
          cv2.destroyWindow('Test Image')

      # Check for message type 0, insert pixel data into image
      elif message[MESSAGE_TYPE_LOCATION] == 0:
        if cameraID == message[MESSAGE_TYPE_LOCATION + 1] and image is not None:
          startRow =\
            (message[MESSAGE_TYPE_LOCATION + 2] << 8) | message[MESSAGE_TYPE_LOCATION + 3]
          startColumn =\
            (message[MESSAGE_TYPE_LOCATION + 4] << 8) | message[MESSAGE_TYPE_LOCATION + 5]
          numPixels = message[MESSAGE_TYPE_LOCATION + 6]
          messageByteIndex = MESSAGE_TYPE_LOCATION + 6
          for p in range(numPixels):
            # Get the pixel for the current column and put it in the image
            messageByteIndex += 1
            image[startRow, startColumn, 2] = message[messageByteIndex]
            messageByteIndex += 1
            image[startRow, startColumn, 1] = message[messageByteIndex]
            messageByteIndex += 1
            image[startRow, startColumn, 0] = message[messageByteIndex]
            # if image[startRow, startColumn, 0] != 0 and \
            #    image[startRow, startColumn, 1] != 0 and \
            #    image[startRow, startColumn, 2] != 0:
            #   print(startRow, '\t', startColumn)
            # Get the next column
            startColumn += 1

  else:
    print("Message ", message_counter, " rejected")

exit(0)
