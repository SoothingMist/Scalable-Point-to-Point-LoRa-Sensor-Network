
Start by reading Background.pdf. That document describes the underlying theory and architecture.

Am preparing something to guide running the software.


