
bool ReceiveMessage(char* message)
{
  // Check if a message is available
  if (rf95.available())
  {
    // Should be a message for us now   
    uint8_t buf[MESSAGE_LENGTH];
    uint8_t len = MESSAGE_LENGTH;
    if (rf95.recv(buf, &len))
    {
      // Ignore if message not from our system
      for(int i = 0; i < MESSAGE_PREFIX_LENGTH; i++)
      {
        if((char)buf[i] != MESSAGE_PREFIX_EXPECTED[i])
        {
          ////Serial.println(F("Message Rejected"));
          return false;
        }
      }

      //Serial.print(F("Received message :  ")); //Serial.println((char*)buf);

      // Convert message to character vector.
      // Tried pointer casting without success.
      for (int i=0; i < MESSAGE_LENGTH; i++) message[i] = (char)buf[i];

      return true;
    }
    else
    {
      //Serial.println(F("Attempt to receive available message failed"));
      for (int i=0; i < MESSAGE_LENGTH; i++) message[i] = '\0';
      return false;
    }
  }
  else
  {
    ////Serial.println(F("No messages available"));
    for (int i=0; i < MESSAGE_LENGTH; i++) message[i] = '\0';
    return false;
  }
}
  
