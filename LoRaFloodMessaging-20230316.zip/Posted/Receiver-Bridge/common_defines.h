
// These defines are common across all node types.
// Needed to ensure standaridzation across all node types for ease of modification.
// Note that defines are used only during compilation.
// They do not exist in global memory during execution.

// LED pin in case we want to use it to demonstrate activity, do not use pin 9
#define LED 13

// Maxium length of the text form of the sensor value
#define maxSensorValueLength 7

// Maxium length of the information/action element
#define maxINFO 15

// Transceiver receives ALL broadcasts from all other transceivers,
// whether or not they are in our network.
// We need a way to differentiate messages.
#define MESSAGE_PREFIX_EXPECTED "MSG"
#define MESSAGE_PREFIX_LENGTH 3

// Due to their fixed-length format, Messages are always this many bytes long, must change as the message format changes
#define MESSAGE_LENGTH 64

// Message format
#define MESSAGE_FORMAT "%3s %5u %5d %5d %5d %5d %5d %15s %7s"

// Pack elements into message
#define PackMessage sprintf(str, MESSAGE_FORMAT, MESSAGE_PREFIX_EXPECTED, SEQ, TYPE, TAGID, RELAYID, TTL, RECEIVED_RSSI, INFO, sensorDataStr);

// Unpack elements from message
#define UnpackMessage sscanf(str, MESSAGE_FORMAT, MESSAGE_PREFIX, &SEQ, &TYPE, &TAGID, &RELAY, &TTL, &RECEIVED_RSSI, INFO, sensorDataStr);

// Time between transmissions (in ms), this particular setting is five seconds
#define TXINTERVAL 5000

// Check the status of the channel every 10 ms
#define CSMATIME 10

// Time between transmissions (milliseconds), 1000 --> one second
#define DELAY 1000

// Given the limited memory on the various nodes, they can only keep track of a limted number of tags
// Choose MAX_TAGS accordingly.
#define MAX_TAGS 25
