
# Want to observe system operation while under production server
#import logging

# So we can get the address of the machine on which this code is running
import socket

import json, random, time
from flask import Flask, render_template, Response, stream_with_context, request, abort
from flask_socketio import SocketIO, emit

# Internet address and port from which connections are allowed.
# Set this to "127.0.0.1" for no-network single-machine local-hosting.
INET_ADDRESS = "127.0.0.1" # access limited to this address
#INET_ADDRESS = "192.168.1.160" # access limited to this address
INET_PORT = 5000

# Internet address from which sensor data messages are received
# Set this to "http://127.0.0.1:9000" for no-network single-machine local-hosting.
#SENSOR_SOURCE = "http://192.168.1.178:9000"
SENSOR_SOURCE = "http://127.0.0.1:9000"

# Pulls in the class for message parsing
# https://stackoverflow.com/questions/4142151/how-to-import-the-class-within-the-same-directory-or-sub-directory
# https://realpython.com/python-sockets/#echo-server
from MessageParserClass import MessageParserClass
MessageParserObject = MessageParserClass() # there should be only one instance of this class

# Configure the log
#formatLog = "%(asctime)s: %(message)s"
#logging.basicConfig(filename='runlog.txt', encoding='utf-8', format=formatLog,
#                    level=logging.INFO, datefmt="%Y-%m-%d %H:%M:%S")

continueThreads = True # threads check this value to see when to stop
messagePosting = "" # These are the messages that are displayed

# Set this variable to "threading", "eventlet" or "gevent" to test the
# different async modes, or leave it set to None for the application to choose
# the best option based on installed packages.
async_mode = None

# Configure the application
app = Flask(__name__)
app.config['SECRET_KEY'] = '#$412_***'
socketio = SocketIO(app, async_mode = async_mode)

# No longer used. Left in for future testing
random.seed()  # Initialize the random number generator

# List of sensors
sensorList = []
selectedSensor = None # The presently-selected sensor name

# History of messages
# https://www.digitalocean.com/community/tutorials/how-to-use-web-forms-in-a-flask-application
messageList =\
[
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message "
]

# Adds a message to the message-history
def updateMessages(message):
    global messagePosting
    messageList.pop(0)
    messageList.append(message)
    messagePosting = ""
    for i in range(len(messageList)): messagePosting += messageList[i] + "<br>"

# Runs once just before every request is accepted.
# Helps to ensure requests are made only from a specific address.
# Does not provide perfect protection.
# https://www.pythonfixing.com/2021/11/fixed-how-to-limit-access-to-flask-for.html
@app.before_request
def limit_remote_addr():
  remoteAddress = request.remote_addr
  routeList = request.access_route
  if remoteAddress != INET_ADDRESS and INET_ADDRESS not in routeList:
    abort(403)  # Forbidden

# Shows the overall display
@app.route('/')
def index():
  return render_template('index.html',
                         selectedSensor = selectedSensor,
                         sensorDictionary = sensorList,
                         messageHistory = messagePosting,
                         async_mode = socketio.async_mode)

@app.route('/chart-data')
def chart_data():
    def generate_data():
        global MessageParserObject, selectedSensor
        t = -1
        while True:
            #sensorData = random.random()
            #sensorID = selectedSensor
            #thisReading = '{"reading": "MSG 508 0 2 0 5 0 SMS:A3 1.00"}'
            thisReading = MessageParserObject.GetNextMessage(SENSOR_SOURCE)
            systemName, sensorID, sensorData =\
              MessageParserObject.ExtractSensorData(thisReading)
            if sensorID is not None:
              updateMessages(thisReading)
              socketio.emit('update_message_history', {'message_history': messagePosting})
              if selectedSensor is None: selectedSensor = sensorID
              if {"name" : sensorID} not in sensorList: sensorList.append({"name" : sensorID})
              if sensorID == selectedSensor:
                t += 1 # increment time tick
                socketio.emit('update_sensor_value', {'sensor_msg': sensorID + ": " + str(sensorData)})
                json_data = json.dumps({'time': str(t), 'value': sensorData})
                yield f"data:{json_data}\n\n"

              time.sleep(0.01) # need a delay here to give time for underlying server processes to run

    response = Response(stream_with_context(generate_data()), mimetype="text/event-stream")
    response.headers["Cache-Control"] = "no-cache"
    response.headers["X-Accel-Buffering"] = "no"
    return response

@socketio.event
def connect():
  updateMessages('Basestation is running.<br>Awaiting data feed.')
  emit('update_message_history', {'message_history': messagePosting})

@app.route("/selectSensor" , methods=['GET', 'POST'])
def selectSensor():
  global selectedSensor
  selectedSensor = request.form.get('comp_select')
  return render_template('index.html',
                         selectedSensor = selectedSensor,
                         sensorDictionary = sensorList,
                         messageHistory = messagePosting,
                         async_mode = socketio.async_mode)

if __name__ == '__main__':

  # socketio.run does not report the address of the hosting machine.
  # Display that information.
  # https://www.simplified.guide/python/hostname-to-ip
  # https://www.codegrepper.com/code-examples/python/how+to+get+my+ip+address+python
  # This approach worked well on a Windows machine wired to the router.
  # However, on a Linux machine connected wirelessly, localhost was returned.
  # For Linux, use the command console and ifconfig to find the actual address.
  # For Windows, use the command console and ipconfig to find the actual address.
  myAddress = socket.gethostbyname(socket.gethostname())
  hostAddress = "http://" + myAddress + ":" + str(INET_PORT)
  print("\nHosting Address: " + hostAddress)

  # Display the address from which connections are accepted.
  print("\nConnections accepted from", "http://" + INET_ADDRESS + ":" + str(INET_PORT), "\n")

  # Start the server.
  # At this level, access is allowed from any address.
  # However, see @app.before_request to see how one can try to limit access to a specific address.

  # Use this when debugging.
  # gevent and gevent-websocket must be uninstalled.
  # simple-websocket must be installed.
  # It is unsafe to use this approach for production purposes.
  socketio.run(app, port=INET_PORT, host="0.0.0.0", debug=True, allow_unsafe_werkzeug=True)

  # Use this when running in production.
  # gevent and gevent-websocket must be installed.
  # simple-websocket must be uninstalled.
  #socketio.run(app, port=INET_PORT, host="0.0.0.0", debug=False, allow_unsafe_werkzeug=False)
