
# Define a class to open/close an address/port and to parse messages.
# https://www.w3schools.com/python/python_classes.asp
# https://docs.python.org/3/tutorial/classes.html

import requests, sys

class MessageParserClass:

  @staticmethod
  def GetNextMessage(sourceAddress):
    # https://realpython.com/python-requests/#:~:text=A%20status%20code%20informs%20you,looking%20for%20was%20not%20found.
    response = None
    while response is None:
      try:
        response = requests.get(sourceAddress)
        response = response.content.decode('ascii')
      except UnicodeDecodeError:
        print("MessageParser: ")
        print("response.content.decode('ascii') failed. Skipping this record.")
        exception = sys.exc_info()[0]  # https://wiki.python.org/moin/HandlingExceptions
        print(exception)
        response = None
      except:
        exception = sys.exc_info()[0]  # https://wiki.python.org/moin/HandlingExceptions
        #print("MessageParser: ", exception)
        response = None

    return response

  @staticmethod
  def ExtractSensorData(reading):
    systemName = None
    messageID = None
    messageType = None
    sensorID = None
    relayID = None
    TTL = None
    RSSI = None
    sensorInfo = None
    sensorData = None

    if reading is not None and reading.find("None") < 0:

      # extract the reading itself
      endText = reading.find(':')
      reading = reading[endText + 3 : len(reading) - 2]

      # extract the reading's elements
      reading = reading.split(" ") # https://stackoverflow.com/questions/5749195/how-can-i-split-and-parse-a-string-in-python

      # Identify the reading's elements.
      # Grabbing all of these, although not all are used in this version of the program.
      systemName = reading[0]
      messageID = reading[1]
      messageType = reading[2]
      sensorID = reading[3]
      relayID = reading[4]
      TTL = reading[5]
      RSSI = reading[6]
      sensorInfo = reading[7]
      sensorData = reading[8]

      # Reform the sensor ID to include information about the sensor
      sensorID = sensorID + ":" + sensorInfo

    # return selected reading elements
    return systemName, sensorID, sensorData
