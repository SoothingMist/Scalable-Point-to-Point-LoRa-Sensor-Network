
// Common subroutine for transmitting LoRa messages

//#include <Arduino.h>
//#include <RH_RF95.h>
//#include "common_defines.h"

bool TransmitMessage(char* message)
{
  uint8_t buf[MESSAGE_LENGTH];
  uint8_t len = MESSAGE_LENGTH;

  // Channel should be idle but if not wait for it to go idle
  rf95.setModeIdle(); // library issue: some obscure bug causing loss of every second message  
  while (rf95.isChannelActive())
  {
    delay(CSMATIME); // wait for channel to go idle by checking frequently
    Serial.println(F("Tag node looping on isChannelActive()"));
  }

  // Convert char to uint8_t.
  // Tried pointer casting but that did not work.
  for (int i=0; i < MESSAGE_LENGTH; i++) buf[i] = (uint8_t)message[i];

  // Send the message
  Serial.print(F("Trying to transmit: "));
  Serial.print((char*)buf);
  if(rf95.send(buf, MESSAGE_LENGTH))
  {
    rf95.waitPacketSent();
    Serial.println(F(" SUCCESS"));
    return true;
  }
  else
  {
    Serial.println(F(" FAILED"));
    Serial.println(F("  Either the message length was invalid and so was not correctly queued for transmit."));
    Serial.println(F("  Or CAD was requested and the CAD timeout timed out before clear channel was detected."));
    return false;
  }
}
