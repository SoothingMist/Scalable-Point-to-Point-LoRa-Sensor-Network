
# References:
# https://realpython.com/python-sockets/#echo-client
# https://realpython.com/python-sockets/#echo-server
# https://eli.thegreenplace.net/2009/07/30/setting-up-python-to-work-with-the-serial-port

from gevent.pywsgi import WSGIServer
import serial, sys, threading, time, socket
from flask import Flask, request, abort
import json, re

# Internet address and port from which connections are allowed.
# Set this to "127.0.0.1" for no-network single-machine local-hosting.
INET_ADDRESS = "127.0.0.1" # access limited to this address
#INET_ADDRESS = "192.168.1.160" # access limited to this address
INET_PORT = 9000

# Connection to Uno serial port
SENSOR_PORT = "COM7" # Serial port used by the sensor system
SENSOR_BAUD = 9600   # Baud rate of the sensor system

continueThreads = True # threads check this value to see when to stop
messageQueue = [] # list of messages received; https://www.geeksforgeeks.org/queue-in-python
messageQueue.clear()
messageQueueLock = threading.Lock()

# Configure the application.
# Not sure why this message appears:
# 'FLASK_ENV' is deprecated and will not be used in Flask 2.3. Use 'FLASK_DEBUG' instead.
# FLASK_ENV is not mentioned anywhere in this code.
# Perhaps one of the imported libraries uses it.
app = Flask(__name__)
app.config['SECRET_KEY'] = '#$412_***'

# Function for disconnecting from a serial port
def DisconnectFromSerialPort():
  global sensor_connection
  if sensor_connection is not None:
    sensor_connection.close()
    sensor_connection = None

# Function for connecting to a serial port
sensor_connection = None
def ConnectToSerialPort():
  global sensor_connection
  while sensor_connection is None:
    try:
      sensor_connection = serial.Serial(SENSOR_PORT, SENSOR_BAUD, timeout=2)
      print("\nSerial connection established to port ", SENSOR_PORT, " at ", SENSOR_BAUD, " baud.")
    except BaseException as Error:  # https://docs.python.org/3/tutorial/errors.html
      if sensor_connection is not None: DisconnectFromSerialPort()
      print(f"\nError opening serial port: {Error}\n{type(Error)=}")
      print("Is the receiver running? Will try again in two seconds.")
      time.sleep(2)

# This thread is an independent shared-memory process that manages the external
# serial data feed.
def ManageDataFeed():
  global continueThreads, messageQueue, messageQueueLock, sensor_connection

  while continueThreads:
    if sensor_connection is None:
      # Reconnect to a serial port.
      ConnectToSerialPort()
    else:
      # Receive and repeat a serial message from Arduino
      try:
        # https://stackoverflow.com/questions/17615414/how-to-convert-binary-string-to-normal-string-in-python3
        # https://stackoverflow.com/questions/16077912/python-serial-how-to-use-the-read-or-readline-function-to-read-more-than-1-char
        # https://www.delftstack.com/howto/python/pyserial-readline
        message = sensor_connection.readline()
      except serial.serialutil.SerialException:
        exception = sys.exc_info()[0]  # https://wiki.python.org/moin/HandlingExceptions
        print(exception)
        sensor_connection.close()
        sensor_connection = None
        break

      if message is not None:
        try:
          message = message.decode('ascii')
          message = message[0 : len(message) - 2] # remove end-of-line
          message = re.sub(' +', ' ', message) # https://www.codegrepper.com/code-examples/python/how+to+remove+redundant+spaces+from+a+string+in+python
          #message = message.split(" ") # https://stackoverflow.com/questions/5749195/how-can-i-split-and-parse-a-string-in-python
          if len(message) > 3 and message[0 : 3] == "MSG":
            messageQueueLock.acquire()
            messageQueue.append(message)
            messageQueueLock.release()
        except UnicodeDecodeError as Error:
          print("Invalid message. Cannot decode to ascii. Skipping")
          print(f"  {Error}, {type(Error)=}")

  DisconnectFromSerialPort()
  print("Message thread finished")

# Runs once just before every request is accepted.
# Helps to ensure requests are made only from a specific address.
# Does not provide perfect protection.
# https://www.pythonfixing.com/2021/11/fixed-how-to-limit-access-to-flask-for.html
@app.before_request
def limit_remote_addr():
  remoteAddress = request.remote_addr
  routeList = request.access_route
  if remoteAddress != INET_ADDRESS and INET_ADDRESS not in routeList:
    abort(403)  # Forbidden

@app.route('/')
def index():
  global messageQueue, messageQueueLock
  messageQueueLock.acquire()
  if len(messageQueue) > 0:
    nextMessage = messageQueue.pop(0)
    #print(nextMessage)
  else: nextMessage = "None"
  messageQueueLock.release()
  return json.dumps({'reading': nextMessage})

# Connect to the specified serial port
ConnectToSerialPort()

# Start the thread that communicates with the Uno receiver
messagingThread = threading.Thread(target=ManageDataFeed)
messagingThread.start()

if __name__ == '__main__':

  # Where is this program hosted?
  # https://www.c-sharpcorner.com/blogs/how-to-find-ip-address-in-python
  print('\nHosting Computer: http://' + socket.gethostbyname(socket.gethostname()) + ":" + str(INET_PORT))

  # From where are queries accepted?
  print('\nQueries accepted from: http://' + str(INET_ADDRESS) + ":" + str(INET_PORT) + "\n")

  # Start the server

  # Use this when debugging.
  #app.run(port=INET_PORT, host="0.0.0.0", debug=False) # refers to connections from any address

  # Use this when in production.
  WSGIServer((INET_ADDRESS, INET_PORT), app).serve_forever()
