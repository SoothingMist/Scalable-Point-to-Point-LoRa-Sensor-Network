
float VolumetricWaterContent(double sensorReading)
{
  /*
   * The volumetric water content (VWC) is the ratio of the volume of water to the unit volume 
   * of soil. Volumetric water content can be expressed as ratio, percentage or depth of 
   * water per depth of soil (assuming a unit surface area), such as inches of water per 
   * foot of soil. 
   *
   * https://extension.okstate.edu/fact-sheets/understanding-soil-water-content-and-thresholds-for-irrigation-management.html
   * 
   * This calculation is based on a calibration and resulting equation that is specific to a particular sensor and soil type.
   */

  float VWC;
  float soil2Voltage = sensorReading * 5.0f / 1023.0f;  //Convert to voltage with 5V input
    
  if(soil2Voltage <= 1.1) VWC = 10.0f * soil2Voltage - 1.0f;
  else if(soil2Voltage > 1.1f && soil2Voltage <= 1.3f) VWC = 25.0f * soil2Voltage - 17.5f;
  else if(soil2Voltage > 1.3f && soil2Voltage <= 1.82) VWC = 48.08f * soil2Voltage - 47.5f;
  else if(soil2Voltage > 1.82f) VWC = 26.32f * soil2Voltage - 7.89f;

  return VWC;
}
