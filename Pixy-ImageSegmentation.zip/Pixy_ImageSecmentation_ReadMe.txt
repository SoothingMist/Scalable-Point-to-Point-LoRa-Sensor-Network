This project sends an image from a camera connected to a microcontroller board, through a USB/Serial connection, to a PC for display.

Pixy-ImageSegmentation-Arduino is written in C++ for an Arduino Uno R3 microcontroller board.
(https://docs.arduino.cc/learn/starting-guide/getting-started-arduino, https://store-usa.arduino.cc/products/arduino-uno-rev3?selectedStore=us)

Connected to the Uno board is a Pixy2.1 camera (https://amzn.to/3zXtiGO). 
Connection instructions can be found at https://docs.pixycam.com/wiki/doku.php?id=wiki:v2:pixy_regular_quick_start.

Pixy-ImageSegmentation-Python is a Python v3 program that runs on a PC. 
It opens the serial port created by the microcontroller and receives LoRa-sized messages from the microcontroller.
Those messages contain image segments from the camera. Those segments are reconstructed into the original image and displayed.
For Python code development and testing, PyCharm Community is a good choice (https://www.jetbrains.com/help/pycharm/installation-guide.html#toolbox).

A 256-byte message size is selected because that is the largest that can be used during LoRa communication. LoRa itself is not used by this demonstration. That is coming later.

It takes about 20 minutes for the image to be fully transmitted. In the end, the camera image is displayed. The reason for this length of time is the method by which the camera's data has to be accessed and the amount of data involved.

Begin by loading the program into the microcontroller.
Then ensure the camera is connected to the microcontroller and the micocontroller is connected to the PC via USB/Serial
In the case of the Uno microcontroller board, power is applied once the PC connection is completed.

Bring up the Python program on the PC and run it. Be sure the program is looking at the correct serial port with the correct baudrate.

Once the program starts running, you will see the following on the console:



HUB_Camera Initialized

Connected to SERIAL_PORT.
	Port Name:  COM11
	Port Baudrate:  9600 

Initiating image transfer
Message  1  of type  3
	b'<Ready to send picture>'
Message  2  of type  1
Message  3  of type  0
Message  4  of type  0

,
,
,

Message  817  of type  0
Message  818  of type  0
Message  819  of type  2
	Image will now display itself.
	The image's window may be hidden under some other application's window.
	To proceed further, click on the image window and click any key.
Message  820  of type  3
	b'<done>'

Process finished with exit code 0


For an explanation of the various message types, open MessageContents.htm in a web browser. The various tabs give details.
