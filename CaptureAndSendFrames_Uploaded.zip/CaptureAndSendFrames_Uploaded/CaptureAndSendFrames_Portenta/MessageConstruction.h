
#pragma once

// Enables Serial.println diagnostics. Use when running with Serial Monitor.
//#define DEBUG

// Adds Arduino's capabilities.
// https://stackoverflow.com/questions/10612385/strings-in-c-class-file-for-arduino-not-compiling
#include <Arduino.h>

// Adds ability to read the Arduino Portenta H7 with Vision Shield - LoRa camera.
#include "camera.h" // Arduino Mbed Core Camera APIs
#include "himax.h"  // API to read from the Himax camera found on the Portenta Vision Shield

// These constants are set for a given node within a given system.
// There is some indication that they can be made permanently 
// resident on the microcontroller board and queried. 
// That can be done once we learn how.
#define SYSTEM_ID 111
#define SOURCE_NODE_ID 001

// Messages are composed of envelope header, envelop footer, and content between those.
// LoRa messages can be no longer than 256 bytes.
// https://www.sciencedirect.com/topics/computer-science/maximum-packet-size#:~:text=LoRa%20offers%20a%20maximum%20packet,be%20found%20in%20%5B5%5D
#define MAX_MESSAGE_SIZE 256
#define ENVELOPE_HEADER_SIZE 8
#define ENVELOPE_FOOTER_SIZE 3

// Images have depth.
// Ex: An RGB image has depth of three. Grayscale has a depth of one.
// Software assumes a depth of no more than 255 and no less than 1.
#define IMAGE_DEPTH 1

// The number of cameras attached to the node running this software.
// Software assumes one.
#define MAX_CAMERAS 1

// Camera parameters
#define IMAGE_HEIGHT 240
#define IMAGE_WIDTH 320
#define IMAGE_MODE CAMERA_GRAYSCALE

// Number of rows and columns to skip at the image's edges.
#define NUMBER_TO_SKIP 0

class MessageConstruction
{

public:

  // Constructor
  MessageConstruction();

  // Destructor
  ~MessageConstruction();

  // Send specific messages to specific destinations.
  // 000 = pixel-level data, 001 = start new image, 002 = end of image. 003 = general notification.
  bool SendMessage_000(uint8_t sourceCameraID, uint8_t destination);
  bool SendMessage_001(uint8_t sourceCameraID, uint8_t destination);
  bool SendMessage_002(uint8_t sourceCameraID, uint8_t destination);
  bool SendMessage_003(String notificationText, uint8_t destination); // only ascii notifications are allowed

private:

  // The message itself
  uint8_t Message[MAX_MESSAGE_SIZE];
  const uint8_t MaxNotificationLength = MAX_MESSAGE_SIZE - ENVELOPE_HEADER_SIZE- ENVELOPE_FOOTER_SIZE - 1;
  uint8_t MessageIndex; // byte possition in current message

  // Outgoing-message counter for this SYSTEM_ID/SOURCE_NODE_ID
  uint16_t sourceMessageID;
  uint8_t sourceMessageID_HighByte;
  uint8_t sourceMessageID_LowByte;

  // Starts a message with its header
  bool StartMessage(uint8_t messageType, uint8_t destination);

  // Add the CRC check value to the message
  bool AddMessageCRC();

  // Transmit the message
  bool TransmitMessage();

  // Get the raw image data (8bpp grayscale)
  unsigned char* CaptureImage();
};
