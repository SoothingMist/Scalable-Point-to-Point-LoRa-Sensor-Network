
# Some references that may be useful later:
# https://www.geeksforgeeks.org/how-to-display-multiple-images-in-one-window-using-opencv-python
# https://answers.opencv.org/question/175912/how-to-display-multiple-images-in-one-window
# https://www.hackster.io/polyhedra64/how-to-link-arduino-serial-to-python-62b9a5
# https://stackoverflow.com/questions/50881227/display-images-in-a-grid

# Libraries that must be imported. See requirements.txt.

# https://pypi.org/project/crcmod
# See Also: https://tanzolab.tanzilli.com/crc
import crcmod  # Methods for generating and decoding message-integrity checks

# https://docs.python.org/3.10/library/time.html
import time         # Python functions regarding clock time

# https://pypi.org/project/opencv-python
import cv2          # OpenCV for processing and displaying images

# https://numpy.org
import numpy as np  # Data manipulation

# https://pypi.org/project/pyserial
import serial       # Serial port interaction

# Global Constants. These values should not be changed.

# Refers to this node
THIS_SYSTEM_ID = 111 # system within which this node is installed
THIS_NODE_ID = 0 # unique for each node in this system's network

# Refers to messages
INITIAL_CRC_VALUE = 0 # lots of ways to use CRC, we stick with this function initialization
MAX_MESSAGE_SIZE = 256 # LoRa messages can be no longer than 256 bytes
EXPECTED_INITIAL_NOTIFICATION = b"<Arduino is Ready>" # first incoming message
EXPECTED_FINAL_MESSAGE = b"<done>" # last incoming message

# Location of elements in message's string.
# Refer to MessageContents.htm in the documentation.
SYSTEM_ID_LOCATION = 1
SOURCE_NODE_ID_LOCATION = 2
DESTINATION_NODE_ID_LOCATION = 3
SOURCE_MESSAGE_ID_LOCATION = 4 # occupies two bytes
MESSAGE_TYPE_LOCATION = 6

# Refers to the microcontroller's serial port
INCOMING_SERIAL_PORT_NAME = 'COM9' # Windows version
#INCOMING_SERIAL_PORT_NAME = '/dev/ttyACM0' # Linux version
INCOMING_SERIAL_PORT_BAUD_RATE = 9600 # port baud rate

# Going global with these variables for now
image = None # matrix holding image data as it arrives
cameraID = None # ID of the particular camera
message_counter = 0 # used for diagnostics, counts number of good incoming messages
incomingSerialPort = None # serial port on the PC side

# Subroutine to unpack a received message
def UnpackMessage(thisMessage):
  global message_counter

  # Check message length. Ignore if not the exact expected length.
  if len(thisMessage) == MAX_MESSAGE_SIZE: # All messages have the same length
    message_counter += 1 # a good message has been received

    # Get the incoming message's CRC value
    CRC_highByte = thisMessage[len(thisMessage) - 3]
    CRC_lowByte = thisMessage[len(thisMessage) - 2]
    expectedCRC = (CRC_highByte << 8) | CRC_lowByte

    # Select CRC-16-DNP to calculate received-message's CRC check value
    crc16 = crcmod.mkCrcFun(0x13D65, 0xFFFF, True, 0xFFFF)

    # Calculate received-message's CRC check value
    calculatedCRC = crc16(thisMessage[0 : len(thisMessage) - 3], INITIAL_CRC_VALUE)
    #for i in range(len(thisMessage)): print(int(thisMessage[i]))

    # Check calculated CRC against CRC embedded in the message
    if expectedCRC == calculatedCRC:
      # Return the message ID
      highByte = thisMessage[SOURCE_MESSAGE_ID_LOCATION]
      lowByte = thisMessage[SOURCE_MESSAGE_ID_LOCATION + 1]
      msgID = (highByte << 8) | lowByte
      return msgID
    else:
      return None
  else: return None

# Main Process
if __name__ == '__main__':

  print("\nIdentifying the microcontroller's serial port:")

  # Identify port to incoming microcontroller
  try:
    incomingSerialPort = serial.Serial(INCOMING_SERIAL_PORT_NAME, INCOMING_SERIAL_PORT_BAUD_RATE)
  except Exception as e:
    print(f'\nCaught {type(e)}:\n', e) # https://docs.python.org/3/tutorial/errors.html
    print("\nIs the incoming microcontroller connected and active?")
    print("Is the incoming microcontroller's IDE's Serial Monitor deactivated?")
    print("Is the incoming port name correct?")
    print("Exiting program.\n")
    exit(1)
  time.sleep(5) # have to wait for microcontroller to be ready
  print("Connected to incoming microcontroller.\n")

  # Clear the input buffer
  while incomingSerialPort.in_waiting > 0: message = incomingSerialPort.read()

  # Send request for picture
  incomingSerialPort.write(b'a')

  # Keep receiving and acting on messages until <done> message is received
  notDone = True
  while notDone:

    # Receive next message
    while incomingSerialPort.in_waiting <= 0: time.sleep(1)
    message = incomingSerialPort.read(MAX_MESSAGE_SIZE)

    # Unpack the message
    messageID = UnpackMessage(message)

    # Check if message is for us and is a good message, ignore otherwise
    if messageID is not None:
      print("Message ", message_counter)
      # Check if message is for this node.
      # Act on message if for this node, ignore otherwise
      if message[SYSTEM_ID_LOCATION] == THIS_SYSTEM_ID and\
         message[DESTINATION_NODE_ID_LOCATION] == THIS_NODE_ID:

        # Check for message type 3, a notification message
        if message[MESSAGE_TYPE_LOCATION] == 3:
          messageContents =\
            message[MESSAGE_TYPE_LOCATION + 2 :
                    MESSAGE_TYPE_LOCATION + 2 + message[MESSAGE_TYPE_LOCATION + 1]]
          print(messageContents)
          if messageContents == EXPECTED_FINAL_MESSAGE: notDone = False

        # Check for message type 1, a start-new-image message
        elif message[MESSAGE_TYPE_LOCATION] == 1:
          # need to start a new image associated with a specific camera
          # https://stackoverflow.com/questions/47242918/how-to-create-an-image-from-a-matrix-using-opencv-python
          # https://numpy.org/doc/stable/reference/random/generated/numpy.random.randint.html
          cameraID = message[MESSAGE_TYPE_LOCATION + 1]
          imageDepth = message[MESSAGE_TYPE_LOCATION + 2]
          numRows =\
            (message[MESSAGE_TYPE_LOCATION + 3] << 8) | message[MESSAGE_TYPE_LOCATION + 4]
          numColumns =\
            (message[MESSAGE_TYPE_LOCATION + 5] << 8) | message[MESSAGE_TYPE_LOCATION + 6]

          # Creates image matrix with random pixel colors.
          image =\
            np.random.randint(0, 255,
                              size = (numRows, numColumns, imageDepth), dtype = np.uint8)

          # Populates image matrix with fixed color.
          # Note: OpenCV represents RGB colors as Blue,Green,Red.
          for r in range(numRows):
            for c in range(numColumns):
              # set red for imageDepth = 3
              #image[r, c, 0] = 0
              #image[r, c, 1] = 0
              #image[r, c, 2] = 255
              # set black for imageDepth = 1
              image[r, c, 0] = 0

          # Show initial image
          # display = np.array(image, dtype = np.uint8)
          # cv2.imshow('Test Image', display)
          # cv2.waitKey(0)
          # cv2.destroyWindow('Test Image')

        # Check for message type 2, an end-of-image message
        elif message[MESSAGE_TYPE_LOCATION] == 2:
          if cameraID == message[MESSAGE_TYPE_LOCATION + 1] and image is not None:
            display = np.array(image, dtype = np.uint8)
            cv2.imshow('Test Image', display)
            cv2.waitKey(0)
            cv2.destroyWindow('Test Image')

        # Check for message type 0, insert pixel data into image
        elif message[MESSAGE_TYPE_LOCATION] == 0:
          # Assumes only one camera in the network, for now
          if cameraID == message[MESSAGE_TYPE_LOCATION + 1] and image is not None:
            # Extract the starting row and column from the message
            startRow =\
              (message[MESSAGE_TYPE_LOCATION + 2] << 8) | message[MESSAGE_TYPE_LOCATION + 3]
            startColumn =\
              (message[MESSAGE_TYPE_LOCATION + 4] << 8) | message[MESSAGE_TYPE_LOCATION + 5]
            numPixels = message[MESSAGE_TYPE_LOCATION + 6] # how many pixels are in the message
            messageByteIndex = MESSAGE_TYPE_LOCATION + 6 # where the pixels are located in the message
            for p in range(numPixels):
              # Get the pixel for the current column and put it in the image
              # The camera in question is grayscale.
              #messageByteIndex += 1
              #image[startRow, startColumn, 2] = message[messageByteIndex]
              #messageByteIndex += 1
              #image[startRow, startColumn, 1] = message[messageByteIndex]
              messageByteIndex += 1 # select the pixel in question
              image[startRow, startColumn, 0] = message[messageByteIndex] # place pixel in matrix

              # Increment picture column
              startColumn += 1

    else:
      # Reject this message
      print("Message ", message_counter, " rejected")

exit(0)
