
#include "MessageConstruction.h" // class declaration

// Constructor
MessageConstruction::MessageConstruction()
{
  // Initialize the camera.
  if(pixy2Camera.init() == PIXY_RESULT_OK)
  {
    pixy2Camera.changeProg("video");
    ImageHeight = pixy2Camera.frameHeight;
    ImageWidth = pixy2Camera.frameWidth;
    #ifdef DEBUG
      Serial.println("\nPixy2 initialized.");
      Serial.print("Camera Height (Rows): "); Serial.println(ImageHeight);
      Serial.print("Camera Width (Columns): "); Serial.println(ImageWidth);
      Serial.flush(); // flush all outgoing data
    #endif
  }
  else
  {
    #ifdef DEBUG
      Serial.println("\n*** Camera initialization failed\n"); Serial.flush(); // flush all outgoing data
    #endif
  }
}

// Transmit a message
bool MessageConstruction::TransmitMessage()
{
  Serial.write(Message, MessageIndex);
  Serial.flush();
  #ifdef DEBUG
    Serial.print("\nSent message of length ");
    Serial.println(MessageIndex); Serial.flush(); // flush all outgoing data
  #endif
  delay(1000); // wait a bit for message transmission to finish
}
  
// Starts a message with its header
bool MessageConstruction::StartMessage(uint8_t messageType, uint8_t destination)
{
  sourceMessageID++;
  for(uint8_t i = 0; i < MAX_MESSAGE_LENGTH; i++) Message[i] = (uint8_t)'\0';
  Message[LOCATION_MESSAGE_BYTES] = 0;
  Message[LOCATION_CRC] = 0;
  Message[LOCATION_CRC + 1] = 0;
  Message[LOCATION_SYSTEM_ID] = SYSTEM_ID;
  Message[LOCATION_SOURCE_ID] = SOURCE_NODE_ID;
  Message[LOCATION_DESTINATION_ID] = destination;
  Message[LOCATION_MESSAGE_ID] = (uint8_t)(sourceMessageID >> 8); // high byte
  Message[LOCATION_MESSAGE_ID + 1] = (uint8_t)((sourceMessageID << 8) >> 8); // low byte
  Message[LOCATION_MESSAGE_TYPE] = messageType;
  Message[LOCATION_SENSOR_ID] = 1; // assuming one sensor per node for now
  Message[LOCATION_REBROADCASTS] = 0; // an original message, not a rebroadcast
  MessageIndex = MESSAGE_HEADER_LENGTH;
  return true;
}

// Adds a 16-bit CRC check value to the message.
// Also adds message footer since CRC is at the end.
bool MessageConstruction::AddMessageCRC()
{
  // Add length of message
  Message[LOCATION_MESSAGE_BYTES] = MessageIndex;
  
  // Add CRC
  uint16_t CRC_Check_Value = checksumCalculator(Message, MessageIndex);
  Message[LOCATION_CRC] = (uint8_t)(CRC_Check_Value >> 8); // high byte
  Message[LOCATION_CRC + 1] = (uint8_t)((CRC_Check_Value << 8) >> 8); // low byte
}

// Send a start-image message
bool MessageConstruction::SendMessage_001(uint8_t destination)
{
  // Start the message with a header
  StartMessage(1, destination);

  // Add the image depth.
  Message[MessageIndex++] = IMAGE_DEPTH;

  // Add the frame dimensions.
  Message[MessageIndex++] = (uint8_t)(ImageHeight >> 8); // high byte
  Message[MessageIndex++] = (uint8_t)((ImageHeight << 8) >> 8); // low byte
  Message[MessageIndex++] = (uint8_t)(ImageWidth >> 8); // high byte
  Message[MessageIndex++] = (uint8_t)((ImageWidth << 8) >> 8); // low byte
  
  // Append message CRC and remaining footer
  AddMessageCRC();

  // Transmit the message
  TransmitMessage();

  return true;
}

// Send all segments of the image's pixels
bool MessageConstruction::SendMessage_000(uint8_t destination)
{
  // Take snapshot.
  // Pixy2.1 cannot take static images.
  // Therefore, physically, the camera has to be held in a staring, continuous-dwell, position.
  // Motion in the image or the camera's motion changes the image as this code tries to send the image.
  // Know that the camera is in video mode. It does not deliver a static snapshot.

  // Paints the image row by row.
  // The number of columns is divided by SegmentSize,
  // the number of pixels that fit within a message envelope.
  // The standard envelope contains MESSAGE_HEADER_LENGTH bytes.
  // The envelope for message type 000 contains an extra 5 bytes.
  const uint8_t SegmentSize = (uint8_t)((NumFreeBytes - 5) / IMAGE_DEPTH);

  // For segmenting the image.
  const uint8_t NumFullColumnBlocks =
    (uint8_t)((ImageWidth - (2 * NUMBER_TO_SKIP)) / SegmentSize); // number of pixels in full column segments
  const uint8_t NumRemainingPixels =
    (uint8_t)((ImageWidth - (2 * NUMBER_TO_SKIP)) % SegmentSize); // number of pixels in the remaining column partial segment

  // Number of rows and columns can be greater than 255 so we have to get low and high bytes of each.
  // columns change constantly but rows change less often.
  uint8_t row_HighByte;
  uint8_t row_LowByte;

  // Values of image colors.
  uint8_t red, green, blue;

  // Send messages containing pixels on a row-by-row basis.
  // Segments of each row's columns are selected as pixels to add to the message.
  // Each message contains no more than SegmentSize number of pixels.
  size_t pixelIndex = 0; // indexes the vector holding the pixel values received from the camera
  for (uint16_t r = NUMBER_TO_SKIP; r < ImageHeight - NUMBER_TO_SKIP; r++)
  {
    row_HighByte = (uint8_t)(r >> 8);
    row_LowByte = (uint8_t)((r << 8) >> 8);
    uint16_t c = NUMBER_TO_SKIP;

    // Go through each SegmentSize block of pixels
    for (uint8_t cb = 0; cb < NumFullColumnBlocks; cb++)
    {
      // Start with the message header
      StartMessage(0, destination);
      
      // Each message contains a block of column pixels for a given row.
      // row and column indicate where a given segment of pixels starts.
      Message[MessageIndex++] = row_HighByte;
      Message[MessageIndex++] = row_LowByte;
      Message[MessageIndex++] = (uint8_t)(c >> 8); // column high byte
      Message[MessageIndex++] = (uint8_t)((c << 8) >> 8); // column low byte
      Message[MessageIndex++] = SegmentSize;

      // Append the pixels in this segment.
      for (uint8_t ss = 0; ss < SegmentSize; ss++)
      {
        // Get this pixel's values
        pixy2Camera.video.getRGB(c, r, &red, &green, &blue, SATURATE);
        Message[MessageIndex++] = red;
        Message[MessageIndex++] = green;
        Message[MessageIndex++] = blue;
        
        // Increment the column counter
        c++;
      }

      // Append message CRC and remaining footer
      AddMessageCRC();
    
      // Transmit the message
      TransmitMessage();
    }

    // Send the pixels in the last partial segment of columns
    if(NumRemainingPixels > 0)
    {
      // Start with the message header
      StartMessage(0, destination);
      
      // Each message contains a block of column pixels for a given row.
      // row and column indicate where a given segment of pixels starts.
      Message[MessageIndex++] = row_HighByte;
      Message[MessageIndex++] = row_LowByte;
      Message[MessageIndex++] = (uint8_t)(c >> 8); // column high byte
      Message[MessageIndex++] = (uint8_t)((c << 8) >> 8); // column low byte
      Message[MessageIndex++] = NumRemainingPixels;
      
      for (c = c; c < ImageWidth - NUMBER_TO_SKIP; c++)
      {
        // Get this pixel's values
        pixy2Camera.video.getRGB(c, r, &red, &green, &blue, SATURATE);
        Message[MessageIndex++] = red;
        Message[MessageIndex++] = green;
        Message[MessageIndex++] = blue;
      }
      
      // Append message CRC and remaining footer
      AddMessageCRC();
    
      // Transmit the message
      TransmitMessage();
    }
  }
}

// 16-bit CRC calculation.
// https://www.tutorialspoint.com/cyclic-redundancy-check-crc-in-arduino
uint16_t MessageConstruction::checksumCalculator(uint8_t * data, uint16_t length)
{
   uint16_t curr_crc = 0x0000; // can use any value here but all nodes must use same value
   uint8_t sum1 = (uint8_t) curr_crc;
   uint8_t sum2 = (uint8_t) (curr_crc >> 8);
   int index;
   for(index = 0; index < length; index++)
   {
      sum1 = (sum1 + data[index]) % 255;
      sum2 = (sum2 + sum1) % 255;
   }
   return (sum2 << 8) | sum1;
}
