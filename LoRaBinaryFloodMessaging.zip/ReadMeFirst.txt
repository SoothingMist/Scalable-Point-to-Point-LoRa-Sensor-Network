
It is important to read Background.pdf first so that you get a basic understanding of the project and what it is trying to accomplish.

Then read Documentation.pdf to see how to use the software with the specified hardware.

MessageContents.htm provides deep detail on the messages that flow through the system. This is your guide if you want to create messages that contain different data.

Glad for your input. Please post in the Issues section of the github website.

