
#include "MessageHandler.h" // class declaration

// Constructor
MessageHandler::MessageHandler()
{
  // Set the LED in case it is needed
  pinMode(LED, OUTPUT);

  // Initialize the message buffer
  for(uint8_t i = 0; i < MAX_MESSAGE_LENGTH; i++) Message[i] = (uint8_t)'\0';

  // Initialize the transceiver
  while (!rf95.init()) delay(100);
  rf95.setFrequency(915.0); // set to 915 MHz for USA
  #ifdef DEBUG
    Serial.println("LoRa initialized."); Serial.flush(); // flush all outgoing data
    Serial.print("rf95.maxMessageLength(): "); Serial.println(rf95.maxMessageLength()); Serial.flush();
    Serial.print("RH_RF95::maxMessageLength: "); Serial.println(RH_RF95_MAX_MESSAGE_LEN); Serial.flush();
    Serial.println();
  #endif
}

// Destructor
MessageHandler::~MessageHandler()
{
}

// Starts a message with its header
bool MessageHandler::StartMessage(uint8_t messageType, uint8_t destination)
{
  sourceMessageID++;
  for(uint8_t i = 0; i < MAX_MESSAGE_LENGTH; i++) Message[i] = (uint8_t)'\0';
  Message[LOCATION_MESSAGE_BYTES] = 0;
  Message[LOCATION_CRC] = 0;
  Message[LOCATION_CRC + 1] = 0;
  Message[LOCATION_SYSTEM_ID] = THIS_SYSTEM_ID;
  Message[LOCATION_SOURCE_ID] = THIS_NODE_ID;
  Message[LOCATION_DESTINATION_ID] = destination;
  Message[LOCATION_MESSAGE_ID] = (uint8_t)(sourceMessageID >> 8); // high byte
  Message[LOCATION_MESSAGE_ID + 1] = (uint8_t)((sourceMessageID << 8) >> 8); // low byte
  Message[LOCATION_MESSAGE_TYPE] = messageType;
  Message[LOCATION_SENSOR_ID] = 1; // assuming one sensor per node for now
  Message[LOCATION_REBROADCASTS] = 0; // an original message, not a rebroadcast
  MessageIndex = MESSAGE_HEADER_LENGTH;
  return true;
}

// 16-bit CRC calculation.
// https://www.tutorialspoint.com/cyclic-redundancy-check-crc-in-arduino
uint16_t MessageHandler::checksumCalculator(uint8_t * data, uint16_t length)
{
   uint16_t curr_crc = 0x0000;
   uint8_t sum1 = (uint8_t)curr_crc;
   uint8_t sum2 = (uint8_t)(curr_crc >> 8);
   for(uint16_t index = 0; index < length; index++)
   {
      sum1 = (sum1 + data[index]) % 255;
      sum2 = (sum2 + sum1) % 255;
   }
   return (sum2 << 8) | sum1;
}

// Send messages.
bool MessageHandler::SendReading(String notificationText, uint8_t destination)
{
  // Start with the message header
  StartMessage(003, destination);
  
  // Add the notification text.
  notificationText = notificationText.substring(0, NumFreeBytes);
  MessageIndex += notificationText.length();
  memcpy(Message + MESSAGE_HEADER_LENGTH, notificationText.c_str(), notificationText.length());

  // Append message CRC and remaining footer
  AddMessageCRC();

  // Transmit the message

  // Channel should be idle but if not wait for it to go idle
  rf95.setModeIdle(); // library issue: some obscure bug causing loss of every second message  
  while (rf95.isChannelActive()) delay(10); // wait for channel to go idle by checking frequently

  // Send the message
  if(rf95.send(Message, Message[LOCATION_MESSAGE_BYTES]))
  {
    rf95.waitPacketSent();
    Serial.println("\tMessage Broadcast");
    return true;
  }
  else
  {
    Serial.println("\tBroadcast failed");
    return false;      
  }
}

// Adds a 16-bit CRC check value to the message.
bool MessageHandler::AddMessageCRC()
{
  // Add length of message
  Message[LOCATION_MESSAGE_BYTES] = MessageIndex;
  
  // Add CRC
  uint16_t CRC_Check_Value = checksumCalculator(Message, MessageIndex);
  Message[LOCATION_CRC] = (uint8_t)(CRC_Check_Value >> 8); // high byte
  Message[LOCATION_CRC + 1] = (uint8_t)((CRC_Check_Value << 8) >> 8); // low byte
  //Serial.write(Message, MAX_MESSAGE_LENGTH); Serial.println(); Serial.println(CRC_Check_Value); Serial.println(MessageIndex); Serial.flush(); exit(0);
}
