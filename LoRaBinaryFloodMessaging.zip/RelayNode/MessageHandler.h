
#pragma once

// Enables Serial.println diagnostics. Use when running with Serial Monitor.
#define DEBUG

// Sets the number of times this relay will rebroadcast a message.
// Maximum value is 255.
#define MAX_REBROADCASTS 5

// Unique ID of this node.
// Relay nodes always have ID = 0.
// They do not originate messages.
// They only rebroadcast messages.
#define THIS_NODE_ID 0
#define THIS_SYSTEM_ID 111

// Adds Arduino's capabilities.
// https://stackoverflow.com/questions/10612385/strings-in-c-class-file-for-arduino-not-compiling
#include <Arduino.h>

// Access to LoRa libraries.
// Install the RadioHead library using Tools/ManageLibraries.
// Compilation may yield, "#warning RH_LoRaFileOps unfinished".
// This does not matter. RadiHead is a work in process.
// We are not using RH_LoRaFileOps.
#include <SPI.h>
#include <RH_RF95.h>

// Byte locations of header components within a message.
// See MessageContents.html for a detailed explanation.
#define LOCATION_MESSAGE_BYTES   0
#define LOCATION_CRC             1
#define LOCATION_SYSTEM_ID       3
#define LOCATION_SOURCE_ID       4
#define LOCATION_DESTINATION_ID  5
#define LOCATION_MESSAGE_ID      6
#define LOCATION_MESSAGE_TYPE    8
#define LOCATION_SENSOR_ID       9
#define LOCATION_REBROADCASTS   10

// Maximum message contents length is set according to the RadioHead library.
#define MAX_MESSAGE_LENGTH RH_RF95_MAX_MESSAGE_LEN

// Given the limited memory on the various nodes, 
// they can only keep track of a limted number of nodes.
// Choose MAX_NODES accordingly.
// Node IDs are assumed to be 1 .. (MAX_NODES -1), inclusive.
// All relay nodes use ID = 0 since they do not originate messages.
#define MAX_NODES 25

// LED pin in case we want to use it to demonstrate activity, do not use pin 9
#define LED 13

class MessageHandler
{

public:

  // Constructor
  MessageHandler();

  // Receive one message.
  bool ReceiveMessage();

  // Check message's CRC
  bool CheckMessageCRC();

  // Rebroadcast as needed
  bool CheckForRebroadcast();

private:

  // The message itself
  uint8_t messageBuffer[MAX_MESSAGE_LENGTH];

  // MUST be always be reintitialized to number of bytes in messageBuffer
  uint8_t messageLength;

  // Singleton instance of the radio driver
  RH_RF95 rf95;

  // List of node IDs and their maximum message ID seen so far.
  // Message IDs are assigned in sequence by the originating node.
  uint16_t LatestMessageID[MAX_NODES];

  // CRC Calculation
  uint16_t checksumCalculator(uint8_t * data, uint16_t length);

  // Retrivals
  uint16_t GetMessageID();
};
