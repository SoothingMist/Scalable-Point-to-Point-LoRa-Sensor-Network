
#include "MessageHandler.h" // class declaration

// Constructor
MessageHandler::MessageHandler()
{
  // Set the LED in case it is needed
  pinMode(LED, OUTPUT);

  // Initialize the message buffer
  for(uint8_t i = 0; i < MAX_MESSAGE_LENGTH; i++) messageBuffer[i] = (uint8_t)'\0';
  messageLength = MAX_MESSAGE_LENGTH;

  // Initialize the message-tracking vector.
  for(uint8_t i = 0; i < MAX_NODES; i++) LatestMessageID[i] = 0;

  // Initialize the transceiver
  while (!rf95.init()) delay(100);
  rf95.setFrequency(915.0); // set to 915 MHz for USA
  #ifdef DEBUG
    Serial.println("LoRa initialized."); Serial.flush(); // flush all outgoing data
    Serial.print("rf95.maxMessageLength(): "); Serial.println(rf95.maxMessageLength()); Serial.flush();
    Serial.print("RH_RF95::maxMessageLength: "); Serial.println(RH_RF95_MAX_MESSAGE_LEN); Serial.flush();
    Serial.println();
  #endif
}

// Receive one message
bool MessageHandler::ReceiveMessage()
{
  // Check if a message is available
  if (rf95.available())
  {
    // Should be a message for us now

    // MUST be reset to number of bytes in messageBuffer.
    // recv() returns with messageLength set to actual length of message.
    // https://www.airspayce.com/mikem/arduino/RadioHead/classRH__RF95.html#a9b402c77236b0dfe3ec68e953faa02dd
    // Also with reference to recv() code itself.
    messageLength = MAX_MESSAGE_LENGTH;
    if(rf95.recv(messageBuffer, &messageLength))
    {
      #ifdef DEBUG
        Serial.print("Received message of length "); Serial.print(messageLength); Serial.println(". ");
      #endif
      return true;
    }
    else return false;
  }
  else return false;
}

// Check message's CRC
bool MessageHandler::CheckMessageCRC()
{
  uint16_t Expected_CRC_Check_Value = (((uint16_t)messageBuffer[LOCATION_CRC]) << 8) | (uint16_t)messageBuffer[LOCATION_CRC + 1];
  messageBuffer[LOCATION_CRC] = 0;
  messageBuffer[LOCATION_CRC + 1] = 0;
  uint16_t Calculated_CRC_Check_Value = checksumCalculator(messageBuffer, messageLength);
  #ifdef DEBUG
    Serial.print('\t'); Serial.print(Calculated_CRC_Check_Value); Serial.print(" / ");
    Serial.println(Expected_CRC_Check_Value); Serial.flush();
  #endif
  if(Calculated_CRC_Check_Value == Expected_CRC_Check_Value)
  {
    messageBuffer[LOCATION_CRC] = (uint8_t)(Calculated_CRC_Check_Value >> 8); // high byte
    messageBuffer[LOCATION_CRC + 1] = (uint8_t)((Calculated_CRC_Check_Value << 8) >> 8); // low byte
    return true;
  }
  else return false;
}

// 16-bit CRC calculation.
// https://www.tutorialspoint.com/cyclic-redundancy-check-crc-in-arduino
uint16_t MessageHandler::checksumCalculator(uint8_t * data, uint16_t length)
{
   uint16_t curr_crc = 0x0000; // can use any value here but it must be the same on all nodes
   uint8_t sum1 = (uint8_t)curr_crc;
   uint8_t sum2 = (uint8_t)(curr_crc >> 8);
   for(uint16_t index = 0; index < length; index++)
   {
      sum1 = (sum1 + data[index]) % 255;
      sum2 = (sum2 + sum1) % 255;
   }
   return (sum2 << 8) | sum1;
}

// Rebroadcast messages as needed.
bool MessageHandler::CheckForRebroadcast()
{
  #ifdef DEBUG
    Serial.print('\t'); Serial.print(messageBuffer[LOCATION_REBROADCASTS]); Serial.print(" / ");
    Serial.println(MAX_REBROADCASTS); Serial.flush();
  #endif

  if(messageBuffer[LOCATION_SOURCE_ID] < MAX_NODES) // can only handle a maximum number of network nodes
  {
    if(messageBuffer[LOCATION_REBROADCASTS] < MAX_REBROADCASTS) // time-to-live exceeded, do not rebroadcast
    {
      #ifdef DEBUG
        Serial.print('\t'); Serial.print(GetMessageID()); Serial.print(" / ");
        Serial.println(LatestMessageID[messageBuffer[LOCATION_SOURCE_ID]]); Serial.flush();
      #endif
      if(GetMessageID() > LatestMessageID[messageBuffer[LOCATION_SOURCE_ID]]) // do not rebroadcast earlier messages
      {
        // Update message table
        if (messageBuffer[LOCATION_MESSAGE_TYPE] == 9) messageBuffer[LOCATION_REBROADCASTS] = 0; //Reset counter
        else LatestMessageID[messageBuffer[LOCATION_SOURCE_ID]] = GetMessageID();
        
        messageBuffer[LOCATION_REBROADCASTS] += 1;
        
        // Add new crc to message
        messageBuffer[LOCATION_CRC] = 0;
        messageBuffer[LOCATION_CRC + 1] = 0;
        uint16_t crc = checksumCalculator(messageBuffer, messageLength);
        uint8_t thisByte;
        messageBuffer[LOCATION_CRC] = (crc | 0x0000) >> 8; // high byte
        messageBuffer[LOCATION_CRC + 1] = 0x0000 | crc; // low byte
        
        // Rebroadcast the message
      
        // Channel should be idle but if not wait for it to go idle
        rf95.setModeIdle(); // library issue: some obscure bug causing loss of every second message  
        while (rf95.isChannelActive()) delay(10); // wait for channel to go idle by checking frequently
    
        // Send the message
        if(rf95.send(messageBuffer, messageLength))
        {
          rf95.waitPacketSent();
          #ifdef DEBUG
            Serial.println("\tMessage Rebroadcast");
          #endif
          return true;
        }
        else
        {
          #ifdef DEBUG
            Serial.println("\tRebroadcast failed");
          #endif
          return false;      
        }
      }
    }
    else return false;
  }
  else return false;
}
  
// Retrievals
uint16_t MessageHandler::GetMessageID()
{
  return (((uint16_t)messageBuffer[LOCATION_MESSAGE_ID]) << 8) |
         (uint16_t)messageBuffer[LOCATION_MESSAGE_ID + 1];
}
