
# https://www.geeksforgeeks.org/how-to-display-multiple-images-in-one-window-using-opencv-python
# https://answers.opencv.org/question/175912/how-to-display-multiple-images-in-one-window
# https://www.hackster.io/polyhedra64/how-to-link-arduino-serial-to-python-62b9a5

# Maybe interesting:
# https://stackoverflow.com/questions/50881227/display-images-in-a-grid

# Importing matplotlib causes this message to appear:
# Backend TkAgg is interactive backend. Turning interactive mode on.
# Not a problem. Just informational.
import time # https://docs.python.org/3.10/library/time.html
import datetime # https://docs.python.org/3.9/library/datetime.html
import matplotlib.pyplot as plt # https://matplotlib.org/stable/index.html
import numpy as np # https://numpy.org
import serial, serial.tools.list_ports # https://pypi.org/project/pyserial
import os # https://docs.python.org/3.10/library/os.html

# Constants are all in capital letters. Those values should not be changed.

# Refers to serial port
Serial_Port = None
SERIAL_PORT_NAME = 'COM12' # Windows
#Serial_PORT_NAME = '/dev/ttyACM1' # Linux
SERIAL_PORT_BAUD_RATE = 9600
#EXPECTED_NODE_IDENTIFIER = "Camera" # identifier sent by the camera node upon connection
EXPECTED_NODE_IDENTIFIER = "Basestation" # identifier sent by the basestation node upon connection

THIS_SYSTEM_ID =   111 # system within which this node is installed
THIS_NODE_ID =       1 # unique for each node containing this code
MAX_MESSAGE_SIZE = 251 # LoRa message content has a maximum size
EXPECTED_FINAL_MESSAGE = b"<done>"

# Byte locations of header components within a message.
# See MessageContents.html for a detailed explanation.
LOCATION_MESSAGE_BYTES =   0
LOCATION_CRC =             1
LOCATION_SYSTEM_ID =       3
LOCATION_SOURCE_ID =       4
LOCATION_DESTINATION_ID =  5
LOCATION_MESSAGE_ID =      6
LOCATION_MESSAGE_TYPE =    8
LOCATION_SENSOR_ID =       9
LOCATION_REBROADCASTS =   10
MESSAGE_HEADER_LENGTH =   11

# Going global with this variable for now.
# Later, will be able to select which camera to display.
cameraID = None

# Database for tracking messages already received.
# https://docs.python.org/3/library/sqlite3.html
import sqlite3
databaseFilename = 'MessagesReceived.db'
os.system('rm ' + databaseFilename) # delete database from last run
databaseConnection = sqlite3.connect(databaseFilename)
databaseCursor = databaseConnection.cursor()
databaseCursor.execute("CREATE TABLE MessageHistory(nodeID, messageID)")
databaseConnection.commit()

# 16-bit CRC calculation.
# https://www.tutorialspoint.com/cyclic-redundancy-check-crc-in-arduino
def checksumCalculator(data, length):
   curr_crc = 0x0000
   sum1 = curr_crc
   sum2 = curr_crc >> 8

   for index in range(length):
      sum1 = (sum1 + data[index]) % 255
      sum2 = (sum2 + sum1) % 255

   return (sum2 << 8) | sum1

# List all serial ports that have a device plugged in.
# https://stackoverflow.com/questions/12090503/listing-available-com-ports-with-python
def FindSerialPorts():
  print("\nSerial Ports:")
  Ports = serial.tools.list_ports.comports()
  found = False
  if Ports is not None:
    print("Detected ", len(Ports), " total ports")
    for port in Ports:
      print(port.name, "\t:\t", port.device, "\t:\t", port.manufacturer)
      found = True
  if not found: print("No ports found")
  print()

# Connect to the correct serial port.
def ConnectSerialPort(GENERIC_PORT_NAME):
  global Serial_Port
  # Identify the device connected to one of the two ports
  try:
    Serial_Port = serial.Serial(SERIAL_PORT_NAME, SERIAL_PORT_BAUD_RATE)
  except Exception as thisException:  # https://docs.python.org/3/tutorial/errors.html
    print(f'\nCaught {type(thisException)}:\n', thisException)
    print("\nIs the ", GENERIC_PORT_NAME, " device connected and active?")
    print("Has ", GENERIC_PORT_NAME, " name and baudrate been correctly specified?")
    print("Is the IDE Serial Monitor of the device connected to ", GENERIC_PORT_NAME, " been deactivated?")
    Serial_Port = None
    return
  time.sleep(5)  # wait long enough for the device to be ready
  # Get the "ready" message, which contains the device's identifier.
  # https://realpython.com/python-print/#preventing-line-breaks
  # https://stackoverflow.com/questions/14292746/how-to-python-convert-bytes-to-readable-ascii-unicode
  identifier = ""
  while Serial_Port.in_waiting > 0: identifier += Serial_Port.read(1).decode("ascii")
  if identifier.find(EXPECTED_NODE_IDENTIFIER) >= 0:
    print("Connected to port ", Serial_Port.name)
  else:
    print("Received unexpected node identifier: ", identifier)
    print('Port Name: ', Serial_Port.name)
    print("\nExiting program.\n")
    Serial_Port.close()
    Serial_Port = None

# Unpack a received message
def UnpackMessage(thisMessage):

  # Check against CRC embedded in the message
  expectedCRC = (thisMessage[LOCATION_CRC] << 8) | thisMessage[LOCATION_CRC + 1]

  # Calculate received-message's CRC check value
  thisMessage = bytearray(thisMessage) # https://linuxhint.com/convert_bytearray_bytes_python
  thisMessage[LOCATION_CRC] = 0
  thisMessage[LOCATION_CRC + 1] = 0
  thisMessage = bytes(thisMessage)
  calculatedCRC = checksumCalculator(thisMessage, len(thisMessage))
  if expectedCRC == calculatedCRC:
    # Return the message ID
    return (thisMessage[LOCATION_MESSAGE_ID] << 8) | thisMessage[LOCATION_MESSAGE_ID + 1]
  else: return None

# Main Process
if __name__ == '__main__':

  # Use this if uncertain as to which serial ports are active
  FindSerialPorts()
  # exit(0)

  # Identify the device connected to the serial port
  print("Configuring serial port...")
  ConnectSerialPort(SERIAL_PORT_NAME)
  if Serial_Port is None:
    print("\nDevice is not connected.")
    print("Exiting program.\n")
    exit(1)

  # Confirm database is available
  print("Working with the following SQLite database:", end = " ")
  print(databaseCursor.execute("SELECT name FROM sqlite_master").fetchall())

  # Tell the LoRa device we are ready to receive and process messages.
  message = "0".encode("utf-8")
  Serial_Port.write(message)
  Serial_Port.flush()

  # Show the blank display
  # The beginning of a user interface.
  # Insights From:
  # https://matplotlib.org/stable/gallery/subplots_axes_and_figures/subplots_demo.html
  # https://stackoverflow.com/questions/44598124/update-frame-in-matplotlib-with-live-camera-preview
  # https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.subplot.html
  # https://learn.sparkfun.com/tutorials/graph-sensor-data-with-python-and-matplotlib/update-a-graph-in-real-time
  # https://www.google.com/search?q=matplotlib+figure+%22clear+subplot+data%22&lr=&sca_esv=554428564&as_qdr=all&biw=877&bih=426&ei=XQ3RZMKtDozK0PEPxcaeuA0&ved=0ahUKEwiC0K-R7sqAAxUMJTQIHUWjB9cQ4dUDCBA&uact=5&oq=matplotlib+figure+%22clear+subplot+data%22&gs_lp=Egxnd3Mtd2l6LXNlcnAiJm1hdHBsb3RsaWIgZmlndXJlICJjbGVhciBzdWJwbG90IGRhdGEiMgUQABiiBDIFEAAYogRIuSpQsQ9Y4SdwBngBkAEAmAH_AaABtw6qAQUwLjkuMbgBA8gBAPgBAcICChAAGEcY1gQYsAPiAwQYACBBiAYBkAYI&sclient=gws-wiz-serp#fpstate=ive&vld=cid:28aa44b8,vid:ARt5rgMnRIU
  # A camera image and sensor data graph are shown side-by-side.
  plt.ion()  # Configure the plotting system for interactive use
  # Configure the plot frame for displaying the camera image and the sensor data graph
  figureFrame, (camera, graph) = plt.subplots(1, 2, num = " ")  # one row, two columns, https://stackoverflow.com/questions/38307438/set-matplotlib-default-figure-window-title
  figureFrame.suptitle('Evolving Display of Camera Image and Data Plot',
                       fontweight="bold")  # https://stackoverflow.com/questions/18962063/matplotlib-setting-title-bold-while-using-times-new-roman
  camera.axis('off')
  camera.title.set_text("Camera")  # https://stackoverflow.com/questions/25239933/how-to-add-a-title-to-each-subplot
  graph.title.set_text("Sensor Data (latest reading date/time")
  plt.show()
  plt.pause(0.1)
  # Data for the line plot
  MAX_SAMPLES = 10  # maximum number of samples appearing on the plot
  x_values = []
  x_labels = []
  y_values = []
  sampleNumber = -1

  # Keep receiving and acting on messages until <done> message is received
  print("Awaiting Messages...\n")
  previousMessageID = 0
  notDone = True
  while notDone:

    # Receive next message.
    # https://www.geeksforgeeks.org/how-to-convert-bytes-to-int-in-python/#
    messageLength = Serial_Port.read() # blocks when no bytes available in the input buffer
    message = messageLength + Serial_Port.read(int.from_bytes(messageLength, 'little') - 1)

    # Unpack the message
    messageID = UnpackMessage(message)

    if messageID is not None:
      print("Message ", messageID, " of type ", message[LOCATION_MESSAGE_TYPE], " (", len(message), ")", end = " ")
      if message[LOCATION_MESSAGE_TYPE] == 1: # // reset message database for a camera node
        databaseCursor.execute("DELETE FROM MessageHistory where nodeID = " + str(message[LOCATION_SOURCE_ID]))
        databaseConnection.commit()
      queryText = "SELECT nodeID, messageID FROM MessageHistory WHERE nodeID = " + \
                  str(message[LOCATION_SOURCE_ID]) + " AND messageID = " + str(messageID)
      queryResult = databaseCursor.execute(queryText).fetchall()
      if len(queryResult) == 0: # otherwise, message is a duplicate, ignore those
        insertText = "INSERT into MessageHistory VALUES (" + \
                     str(message[LOCATION_SOURCE_ID]) + ", " + str(messageID) + ")"
        databaseCursor.execute(insertText)
        databaseConnection.commit()
      else:
        print(" *** Duplicate")
        continue
      print()
      previousMessageID = messageID
      # Check if message is for this node.
      # Act on message if for this node.
      if message[LOCATION_SYSTEM_ID] == THIS_SYSTEM_ID and\
         message[LOCATION_DESTINATION_ID] == THIS_NODE_ID:

        # Check for message type 9, node-message reset
        # https://www.tutlane.com/tutorial/sqlite/sqlite-delete-statement
        if message[LOCATION_MESSAGE_TYPE] == 9:
          databaseCursor.execute("DELETE FROM MessageHistory where nodeID = " + str(message[LOCATION_SOURCE_ID]))
          databaseConnection.commit()

        # Check for message type 3, text-only notification
        elif message[LOCATION_MESSAGE_TYPE] == 3:
          messageContents = message[MESSAGE_HEADER_LENGTH : len(message)]
          print('\t', messageContents)
          messageDecoded = messageContents.decode('ascii').split(':') # https://www.freecodecamp.org/news/how-to-parse-a-string-in-python
          if messageDecoded[0] == "DATA":
            # https://www.tutorialspoint.com/how-to-rotate-tick-labels-in-a-subplot-in-matplotlib
            # https://www.geeksforgeeks.org/matplotlib-axes-axes-set_xticklabels-in-python
            sampleNumber += 1
            now = str(datetime.datetime.now()) # get the current date and time
            now = now[0: now.rfind('.')] # format for this application
            x_values.append(sampleNumber)
            x_labels.append(now)
            y_values.append(float(messageDecoded[2]))
            x_values = x_values[-MAX_SAMPLES:]
            x_labels = x_labels[-MAX_SAMPLES:]
            y_values = y_values[-MAX_SAMPLES:]
            graph.clear()  # clears plot data
            #graph.set_xticklabels(x_labels, rotation=90) # does not fit, need to figure out
            graph.set_ylim([0.0, 6])
            graph.title.set_text("Sensor Data (" + now + "," + str(messageDecoded[2]) + " volts)")
            graph.set_ylabel(messageDecoded[1]) # https://matplotlib.org/stable/api/_as_gen/matplotlib.axes.Axes.set_xlabel.html
            graph.set_xlabel('Sample Number')
            graph.plot(x_values, y_values, 'o')
            plt.show()
            plt.pause(0.1)

        # Check for message type 1, start-new-image
        elif message[LOCATION_MESSAGE_TYPE] == 1:
          # need to start a new image associated with a specific camera
          # https://stackoverflow.com/questions/47242918/how-to-create-an-image-from-a-matrix-using-opencv-python
          # https://numpy.org/doc/stable/reference/random/generated/numpy.random.randint.html
          cameraID = message[LOCATION_SENSOR_ID]
          imageDepth = message[MESSAGE_HEADER_LENGTH]
          numRows =\
            (message[MESSAGE_HEADER_LENGTH + 1] << 8) | message[MESSAGE_HEADER_LENGTH + 2]
          numColumns =\
            (message[MESSAGE_HEADER_LENGTH + 3] << 8) | message[MESSAGE_HEADER_LENGTH + 4]
          print('\t', numRows, " / ", numColumns)

          # https://stackoverflow.com/questions/44598124/update-frame-in-matplotlib-with-live-camera-preview

          # Create basic image matrix
          imageMatrix = np.random.randint(0, 255, size=(numRows, numColumns, imageDepth), dtype=np.uint8)
          image = camera.imshow(imageMatrix)  # create an image plot

          # Populate image matrix with blue color.
          for r in range(numRows):
            for c in range(numColumns):
              imageMatrix[r, c, 0] =   0
              imageMatrix[r, c, 1] =   0
              imageMatrix[r, c, 2] = 255

          # Show the image
          image.set_data(imageMatrix)
          plt.show()
          plt.pause(0.1)

        # Check for message type 0, insert pixel data into image
        elif message[LOCATION_MESSAGE_TYPE] == 0:
          if cameraID == message[LOCATION_SENSOR_ID] and image is not None:
            startRow =\
              (message[MESSAGE_HEADER_LENGTH] << 8) | message[MESSAGE_HEADER_LENGTH + 1]
            startColumn =\
              (message[MESSAGE_HEADER_LENGTH + 2] << 8) | message[MESSAGE_HEADER_LENGTH + 3]
            numPixels = message[MESSAGE_HEADER_LENGTH + 4]
            messageByteIndex = MESSAGE_HEADER_LENGTH + 5
            print("\t", startRow, " / ", startColumn)
            for p in range(numPixels):
              # Get the pixel for the current column and put it in the image
              imageMatrix[startRow, startColumn, 0] = message[messageByteIndex]
              messageByteIndex += 1
              imageMatrix[startRow, startColumn, 1] = message[messageByteIndex]
              messageByteIndex += 1
              imageMatrix[startRow, startColumn, 2] = message[messageByteIndex]
              messageByteIndex += 1
              # Get the next column
              startColumn += 1
            image.set_data(imageMatrix)
            plt.show()
            plt.pause(0.1)

          else: print("Unidentifiable Message Rejected")

  # Finished
  print("\nFinished.\n")
  Serial_Port.close()
  Serial_Port = None
  exit(0)
