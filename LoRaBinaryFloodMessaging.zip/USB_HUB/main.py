
# This program looks for two serial ports.
# Data from one is sent to the other.
# Thus, it is possible to send data from one device to another
# when those two devices cannot be plugged together.

# Required for working with serial ports
# https://pypi.org/project/pyserial
import serial.tools.list_ports

# Required to keep track of time.
import time

# Variables and constants associated with the two serial ports.
Generic_Port = None # used to open port prior to port's function assignment
GENERIC_PORT_BAUD_RATE = 9600
GENERIC_PORT_A_NAME = 'COM12' # Windows
#GENERIC_PORT_A_NAME = '/dev/ttyACM1' # Linux
GENERIC_PORT_B_NAME = 'COM11' # Windows
#GENERIC_PORT_B_NAME = '/dev/ttyACM0' # Linux
LoRa_Port = None
Camera_Port = None
MAX_MESSAGE_LENGTH = 251 # maximum accepted by Dragino LoRa module.

# List all serial ports that have a device plugged in.
# https://stackoverflow.com/questions/12090503/listing-available-com-ports-with-python
def FindSerialPorts():
  print("\nSerial Ports:")
  Ports = serial.tools.list_ports.comports()
  found = False
  if Ports is not None:
    print("Detected ", len(Ports), " total ports")
    for port in Ports:
      #if port.manufacturer is not None and "PORT_A" in port.manufacturer:
        print(port.name, "\t:\t", port.device, "\t:\t", port.manufacturer)
        found = True
  if not found: print("No ports found")
  print()

# Connect to the correct serial ports.
# An assumption is that each node generates a text-only message upon starting.
def ConnectSerialPort(GENERIC_PORT_NAME):
  global Generic_Port, LoRa_Port, Camera_Port
  # Identify the device connected to one of the two ports
  try:
    Generic_Port = serial.Serial(GENERIC_PORT_NAME, GENERIC_PORT_BAUD_RATE)
  except Exception as thisException:  # https://docs.python.org/3/tutorial/errors.html
    print(f'\nCaught {type(thisException)}:\n', thisException)
    print("\nIs the ", GENERIC_PORT_NAME, " device connected and active?")
    print("Has ", GENERIC_PORT_NAME, " name and baudrate been correctly specified?")
    print("Is the IDE Serial Monitor of the device connected to ", GENERIC_PORT_NAME, " been deactivated?")
    print("Exiting program.\n")
    exit(1)
  # Get the "ready" message, which contains the device's identifier.
  # https://realpython.com/python-print/#preventing-line-breaks
  # https://stackoverflow.com/questions/14292746/how-to-python-convert-bytes-to-readable-ascii-unicode
  identifier = ""
  while Generic_Port.in_waiting < 1: time.sleep(5) # wait long enough for the device to be ready
  while Generic_Port.in_waiting > 0: identifier += Generic_Port.read(1).decode("ascii")
  if identifier.find("LoRa") >= 0:
    LoRa_Port = Generic_Port
    print("LoRa device connected to port ", LoRa_Port.name)
  elif identifier.find("Camera") >= 0:
    Camera_Port = Generic_Port
    print("Camera device connected to port ", Camera_Port.name)
  else:
    print("Received unknown device identifier: ", identifier)
    print('\tPort Name: ', Generic_Port.name)
    print("Exiting program.\n")
    exit(1)

  Generic_Port = None

# Main Process
if __name__ == '__main__':
  
  # Use this if uncertain as to which serial ports are active
  FindSerialPorts()
  #exit(0)

  # Identify the devices connected to the serial ports
  print("Configuring serial ports...")
  ConnectSerialPort(GENERIC_PORT_A_NAME)
  ConnectSerialPort(GENERIC_PORT_B_NAME)
  if Camera_Port is None:
    print("Camera node not connected.")
    print("Exiting program.\n")
    exit(1)
  if LoRa_Port is None:
    print("LoRa node not connected.")
    print("Exiting program.\n")
    exit(1)

  # Start the transfer of data from camera node to LoRa node.
  message = "0".encode("utf-8")
  Camera_Port.write(message)
  Camera_Port.flush()
  m = 0 # count messages

  # Receive messages from the camera node. Send those to the LoRa node.
  print("\nAwaiting Messages...\n")
  while True: # for continuous operation
    if Camera_Port.in_waiting > 0:

      # Receive next message.
      # https://www.geeksforgeeks.org/how-to-convert-bytes-to-int-in-python/#
      messageLength = Camera_Port.read()
      message = Camera_Port.read(int.from_bytes(messageLength, 'little') - 1)

      # Check if camera is awaiting go-ahead for sending its next image
      if str(message).find("Camera Ready") >= 0:
        while Camera_Port.in_waiting > 0: Camera_Port.read(1) # flush input buffer
        print('\n', message.decode('ascii'))
        input(" Press <enter> to start next image transfer:\n")
        message = "0".encode("utf-8")
        Camera_Port.write(message)
        Camera_Port.flush()
        m = 0
        continue

      m += 1
      message = messageLength + message

      # Send message from the hub to a microcontroller.
      # This method is unusual. Why this "one byte at a time" approach?
      # Reason: Found that sending all the bytes at once, in one statement,
      # overwhelms the serial buffer on the microcontroller.
      # A microcontroller is a LOT slower than a computer. Thus, it is possible for the
      # computer to send data too fast to the microcontroller. Some means is needed to
      # slow things down. Chose this approach. There may be others. This one works well.
      # Keep in mind that a USB/Serial port is not a physical serial port. Rather, it is
      # a simulation of one, albeit a very good simulation. One has to accommodate that
      # fact and not expect USB/Serial ports to work as efficiently as physical ports.
      # Encoding individual bytes in a message derived from
      # https://stackoverflow.com/questions/32018993/how-can-i-send-a-byte-array-to-a-serial-port-using-python
      for i in range(len(message)): LoRa_Port.write(bytearray([message[i]]))
      LoRa_Port.flush()

      # Receive and repeat feedback
      print("Forwarded Message ", m, "(", len(message), ") Feedback: ",
            LoRa_Port.readline().decode('ascii'), end = "")

      # Receive and compare echo
      messageLength = LoRa_Port.read()
      print("\tTrying to read echo message of length ", int.from_bytes(messageLength, 'little') , end = "")
      echo = messageLength + LoRa_Port.read(int.from_bytes(messageLength, 'little') - 1)
      if message != echo:
        print(" *** Echo did not match", " (", len(echo), ")")
      else: print(". Echo matched")

  # Finished
  print("\nFinished.\n")
  Camera_Port.close()
  Camera_Port = None
  LoRa_Port.close()
  LoRa_Port = None
  exit(0)
