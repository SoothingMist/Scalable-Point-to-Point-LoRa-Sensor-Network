
#include "MessageHandler.h" // class declaration

// Constructor
MessageHandler::MessageHandler()
{
  // Set the LED in case it is needed
  pinMode(LED, OUTPUT);

  // Initialize the message buffer
  for(uint8_t i = 0; i < MAX_MESSAGE_LENGTH; i++) messageBuffer[i] = (uint8_t)'\0';
  messageLength = MAX_MESSAGE_LENGTH; // must always be reset to this value

  // Initialize the transceiver
  while (!rf95.init()) delay(100);
  rf95.setFrequency(915.0); // set to 915 MHz for USA
  #ifdef DEBUG
    Serial.println("LoRa initialized."); Serial.flush(); // flush all outgoing data
    Serial.print("rf95.maxMessageLength(): "); Serial.println(rf95.maxMessageLength()); Serial.flush();
    Serial.print("RH_RF95::maxMessageLength: "); Serial.println(RH_RF95_MAX_MESSAGE_LEN); Serial.flush();
    Serial.println();
  #endif
}

// Receive one message
bool MessageHandler::ReceiveMessage()
{
  // Check if a message is available
  if (rf95.available())
  {
    // Should be a message for us now

    // MUST be reset to number of bytes in messageBuffer.
    // recv() returns with messageLength set to actual length of message.
    // https://www.airspayce.com/mikem/arduino/RadioHead/classRH__RF95.html#a9b402c77236b0dfe3ec68e953faa02dd
    // Also with reference to recv() code itself.
    messageLength = MAX_MESSAGE_LENGTH;
    if(rf95.recv(messageBuffer, &messageLength))
    {
      #ifdef DEBUG
        Serial.print("Received message of length "); Serial.print(messageLength); Serial.println(". ");
      #endif
      return true;
    }
    else return false;
  }
  else return false;
}

// Check message's CRC
bool MessageHandler::CheckMessageCRC()
{
  uint16_t Expected_CRC_Check_Value =
    (((uint16_t)messageBuffer[LOCATION_CRC]) << 8) | (uint16_t)messageBuffer[LOCATION_CRC + 1];
  messageBuffer[LOCATION_CRC] = 0;
  messageBuffer[LOCATION_CRC + 1] = 0;
  uint16_t Calculated_CRC_Check_Value = checksumCalculator(messageBuffer, messageLength);
  #ifdef DEBUG
    Serial.print('\t'); Serial.print(Calculated_CRC_Check_Value); Serial.print(" / ");
    Serial.println(Expected_CRC_Check_Value); Serial.flush();
  #endif
  if(Calculated_CRC_Check_Value == Expected_CRC_Check_Value)
  {
    messageBuffer[LOCATION_CRC] = (uint8_t)(Calculated_CRC_Check_Value >> 8); // high byte
    messageBuffer[LOCATION_CRC + 1] = (uint8_t)((Calculated_CRC_Check_Value << 8) >> 8); // low byte
    return true;
  }
  else return false;
}

// 16-bit CRC calculation.
// https://www.tutorialspoint.com/cyclic-redundancy-check-crc-in-arduino
uint16_t MessageHandler::checksumCalculator(uint8_t * data, uint16_t length)
{
   uint16_t curr_crc = 0x0000; // can use any value here but it must be the same on all nodes
   uint8_t sum1 = (uint8_t)curr_crc;
   uint8_t sum2 = (uint8_t)(curr_crc >> 8);
   for(uint16_t index = 0; index < length; index++)
   {
      sum1 = (sum1 + data[index]) % 255;
      sum2 = (sum2 + sum1) % 255;
   }
   return (sum2 << 8) | sum1;
}

// Compares myID with message's source ID
bool MessageHandler::CheckNodeID(uint8_t myID)
{
  if(messageBuffer[LOCATION_DESTINATION_ID] == myID)
   {
     Serial.write(messageBuffer, messageLength); Serial.flush();
     return true;
   }
   else return false;
}
